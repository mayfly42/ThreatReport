# typed: true
# frozen_string_literal: true

require "react_payload"

# rubocop:todo GitHub/RailsControllerRenderLiteral

class PullRequestsController < AbstractRepositoryController
  # All other actions will be mapped to the pull_requests service
  map_to_service :checks_api, only: [:checks] # rubocop:todo GitHub/MapToService

  include ShowPartial, MarketplaceHelper,
    TimelineHelper, HydroHelper, GateRequestHelper, ConditionalAccessDependency, SiteHelper,
    ControllerMethods::Codespaces, PullRequests::FileTreeHelper, FileFilterHelper,
    ControllerMethods::PullRequests, PullRequests::DiffContentLoadingHelper,
    ApplicationController::PartialRenderWithLayoutDependency, PullRequests::MergeboxHelper,
    PullRequests::NewFilesChangedHelper, PullRequests::PageTitleHelper, Commits::ReactPayloadDataDependency, BranchesHelper,
    ApplicationController::VerifiedFetchDependency, ActionView::Helpers::TextHelper, PullRequests::DatabaseSelection, Issues::RateLimitsDependency,
    Issues::RepositoryClusterDependency, ControllerMethods::Issues,
    PullRequests::ReactDependency, PullRequests::ChecksDependency, DashboardHelper

  allow_verified_fetch only: [:files, :show, :run_action_required_workflows]

  helper :compare

  rescue_from_timeout_without_replay only: [:merge] do
    T.bind(self, PullRequestsController)

    GitHub.dogstats.increment("pull_requests.merge_timeout_rescued")

    orchestration = PullRequests::Orchestrations::Merge.active.find_by(pull_request_id: @pull&.id)
    orchestration&.end_orchestration(:failed, "merge timed out")

    render_update_content_json({
      merging: render_to_string(
        partial: "pull_requests/merging",
        object: @pull,
        formats: :html,
        locals: {
          merging_error: {
            form_target: "js-merge-branch-form",
            unretryable: false,
            title: "Merge attempt failed",
            message: ("Merge attempt timed out."),
          },
        },
      ),
    }, status: :gateway_timeout)
  end

  around_action :with_replica_repository_cluster, only: [:update]
  before_action :set_page_responsive
  before_action :all_color_mode_themes, only: [:checks]
  skip_before_action :authorization_required, only: %w(dashboard show_menu_content)
  before_action :require_pull_requests_enabled, except: [:index]

  before_action :login_required, only: [:dashboard, :create, :comment, :merge_button, :dismiss_protip, :ready_for_review, :convert_to_draft, :change_base, :apply_suggestions, :run_action_required_workflows, :edit_form, :update]
  before_action :login_required_redirect_for_public_repo, only: [:new]
  before_action :writable_repository_required,
    except: %w(
      actions_menu
      changes
      changes_since_last_review
      checks
      cleanup
      code_menu_contents
      commits
      findings
      convert_to_draft
      deferred_commits_data
      diff
      files
      index
      merge_button
      new
      open_with_menu
      patch
      ready_for_review
      show
      show_partial
      show_menu_content
      timeline_more_items
      undo_cleanup
      linked_closing_reference
      layout
    )
  before_action :issue_modifiers_only, only: %w(triage)
  before_action :check_for_empty_repository, only: [:create, :new]
  before_action :no_cache
  before_action :ensure_pull_head_pushable, only: [:cleanup, :undo_cleanup, :cleanup_codespaces]
  before_action :issue_modifiers_only, only: %w(update)
  before_action :issue_required, only: [:update]
  before_action :content_authorization_required, only: [:create, :merge, :apply_suggestions, :update]
  before_action :external_identity_session_required, only: [:index]
  before_action :handle_changes_route_redirects, only: [:files, :commits, :changes]
  before_action :handle_overview_route_redirects, only: [:show]

  check_for_sso [:dashboard]

  before_action :require_can_lock, only: [:lock]
  before_action :require_can_unlock, only: [:unlock]
  before_action :require_can_archive, only: [:archive]
  before_action :require_can_unarchive, only: [:unarchive]
  before_action :set_milestone_permission_required, only: %w(set_milestone)
  skip_before_action :cap_pagination, unless: :robot?

  before_action :disable_turbo_navigation, only: [:files, :changes]

  prepend_around_action :use_repository_cluster_replicas, only: [:create, :update]
  prepend_around_action :use_user_cluster_replicas, only: [:create, :comment, :update]
  prepend_around_action :use_collab_cluster_replicas, only: [:create]

  around_action :record_stats, only: [:show, :files, :commits, :changes]

  layout "repository"
  global_navigation_title "Pull requests", only: [:dashboard]

  javascript_bundle :codespaces
  javascript_bundle :diffs
  javascript_bundle :scanning, only: [:show, :files, :checks]
  javascript_bundle :"code-menu"
  javascript_bundle :"pull-requests-list"
  javascript_bundle :"pull-requests", only: [:show]
  stylesheet_bundle :code
  stylesheet_bundle :"pull-requests"
  stylesheet_bundle "copilot-code-review"
  stylesheet_bundle :actions, only: [:show, :files, :checks, :changes, :commits]

  param_encoding :create, :base, "ASCII-8BIT"
  param_encoding :create, :head, "ASCII-8BIT"
  param_encoding :new, :range, "ASCII-8BIT"

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::IamAbilities,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::NotificationsEntries,
    ApplicationRecord::Repositories,
    ApplicationRecord::Spokes,
    optional: false, only: [:linked_closing_reference]

  depends_on_clusters ApplicationRecord::Copilot,
    only: [:linked_closing_reference],
    optional: true

  depends_on_clusters ApplicationRecord::Mysql5,
    ApplicationRecord::RepositoriesPushes,
    only: [:layout],
    optional: true

  depends_on_clusters ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::SecurityProductsEnablement,
    ApplicationRecord::IamAbilities,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Repositories,
    ApplicationRecord::Spokes,
    ApplicationRecord::Iam,
    optional: false, only: [:files, :commits, :diff, :conversations_menu, :show_partial_comparison, :show_toc, :merge_button, :resolve_conflicts, :code_menu_contents, :checks, :findings, :timeline_more_items, :new, :open_with_menu, :changes_since_last_review, :patch, :update]

  # The 404 error page rendered when #update is called for a non-existent
  # issue/PR includes the marketing header, which loads its persisted GraphQL
  # operation via Platform::OperationStore (ballast).
  depends_on_clusters ApplicationRecord::Ballast,
    only: [:update],
    optional: true

  rate_limit_requests \
    only: [:patch],
    if: :patch_action_request_is_rate_limited?,
    key: :patch_action_rate_limit_key,
    max: GitHub::RateLimitedRequest::DEFAULT_RATE_LIMIT_MAX,
    ttl: GitHub::RateLimitedRequest::DEFAULT_RATE_LIMIT_TTL

  #      _              _
  #  ___| |_ ___  _ __ | |
  # / __| __/ _ \| '_ \| |
  # \__ \ || (_) | |_) |_|
  # |___/\__\___/| .__/(_)
  #              |_|
  # By adding a cluster to this list, you are asserting that the
  # Pull Request page should respond with a 500 error when that
  # cluster is unavailable. Those kinds of changes should not be
  # made without talking with the Pull Requests team first.
  depends_on_clusters(
    ApplicationRecord::Billing,
    ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::Iam,
    ApplicationRecord::IamAbilities,
    ApplicationRecord::InProductTargeting,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Mysql1,
    ApplicationRecord::NotificationsEntries,
    ApplicationRecord::Permissions,
    ApplicationRecord::Repositories,
    ApplicationRecord::RepositoriesPushes,
    ApplicationRecord::Spokes,
    optional: false, only: [:show]
  )

  depends_on_clusters(
    ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Notify,
    ApplicationRecord::Repositories,
    ApplicationRecord::RepositoriesPushes,
    ApplicationRecord::Spokes,
    optional: false, only: [:layout]
  )

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Billing,
    ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::Copilot,
    ApplicationRecord::Iam,
    ApplicationRecord::IamAbilities,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Notify,
    ApplicationRecord::Permissions,
    ApplicationRecord::Repositories,
    ApplicationRecord::Spokes,
    optional: false, only: [:show_menu_content]

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::Copilot,
    ApplicationRecord::Iam,
    ApplicationRecord::IamAbilities,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Notify,
    ApplicationRecord::Repositories,
    ApplicationRecord::Spokes,
    optional: false, only: [:actions_menu]

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Billing,
    ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::Iam,
    ApplicationRecord::IamAbilities,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Notify,
    ApplicationRecord::Repositories,
    ApplicationRecord::RepositoriesActionsChecks,
    ApplicationRecord::Spokes,
    optional: false, only: [:edit_form]

  depends_on_clusters ApplicationRecord::Copilot,
    only: [:edit_form], optional: true

  depends_on_clusters \
    ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::IamAbilities,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Repositories,
    optional: false, only: [:index]

  depends_on_clusters \
    ApplicationRecord::Ballast,
    ApplicationRecord::Billing,
    ApplicationRecord::Copilot,
    ApplicationRecord::Iam,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::NotificationsEntries,
    ApplicationRecord::Notify,
    ApplicationRecord::Permissions,
    ApplicationRecord::RepositoriesActionsChecks,
    ApplicationRecord::Spokes,
    ApplicationRecord::Pages,
    optional: true, only: [:index]

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Copilot,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Notify,
    ApplicationRecord::Iam,
    ApplicationRecord::RepositoriesActionsChecks,
    optional: true, only: [:show, :code_menu_contents]

  depends_on_clusters(
    ApplicationRecord::Billing,
    ApplicationRecord::Iam,
    ApplicationRecord::NotificationsEntries,
    ApplicationRecord::Permissions,
    ApplicationRecord::RepositoriesPushes,
    optional: false, only: [:files]
  )
  depends_on_clusters(
    ApplicationRecord::Authnd,
    ApplicationRecord::Ballast,
    ApplicationRecord::Copilot,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Notify,
    ApplicationRecord::RepositoriesActionsChecks,
    optional: true, only: [:files]
  )

  depends_on_clusters ApplicationRecord::Iam,
    ApplicationRecord::Permissions,
    ApplicationRecord::RepositoriesActionsChecks,
    optional: false, only: [:commits]

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Billing,
    ApplicationRecord::Copilot,
    ApplicationRecord::Memex, # repo header link count
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Notify,
    ApplicationRecord::NotificationsEntries,
    ApplicationRecord::RepositoriesPushes,
    optional: true, only: [:commits]

  # Changes action combines commits and files behavior, so it needs both sets of dependencies
  depends_on_clusters ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::Iam,
    ApplicationRecord::IamAbilities,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Permissions,
    ApplicationRecord::Repositories,
    ApplicationRecord::RepositoriesActionsChecks,
    ApplicationRecord::Spokes,
    optional: false, only: [:changes]

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Billing,
    ApplicationRecord::Copilot,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Notify,
    ApplicationRecord::NotificationsEntries,
    ApplicationRecord::RepositoriesPushes,
    ApplicationRecord::SecurityProductsEnablement,
    optional: true, only: [:changes]

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    optional: false, only: [:diff]

  depends_on_clusters ApplicationRecord::Iam,
    ApplicationRecord::Mysql2,
    optional: false, only: [:conversations_menu]

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Billing,
    ApplicationRecord::Copilot,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Memex,
    ApplicationRecord::RepositoriesActionsChecks,
    optional: true, only: [:conversations_menu]

  depends_on_clusters ApplicationRecord::Iam,
    ApplicationRecord::Mysql2,
    optional: false, only: [:show_partial_comparison]

  depends_on_clusters ApplicationRecord::Billing,
    ApplicationRecord::Copilot,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Notify,
    ApplicationRecord::RepositoriesActionsChecks,
    optional: true, only: [:show_partial_comparison]

  depends_on_clusters ApplicationRecord::Iam,
    ApplicationRecord::Mysql2,
    optional: false, only: [:show_toc]

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Copilot,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql5,
    ApplicationRecord::RepositoriesActionsChecks,
    optional: true, only: [:show_toc]

  depends_on_clusters ApplicationRecord::Memex,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Permissions,
    ApplicationRecord::RepositoriesActionsChecks,
    optional: false, only: [:merge_button]

  depends_on_clusters ApplicationRecord::Memex,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::NotificationsEntries,
    optional: false, only: [:resolve_conflicts]

  depends_on_clusters ApplicationRecord::Copilot,
    optional: true, only: [:resolve_conflicts]

  depends_on_clusters ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::NotificationsEntries,
    optional: false, only: [:code_menu_contents]

  depends_on_clusters ApplicationRecord::Iam,
    ApplicationRecord::NotificationsEntries,
    ApplicationRecord::Permissions,
    ApplicationRecord::RepositoriesActionsChecks,
    ApplicationRecord::RepositoriesPushes,
    optional: false, only: [:checks]

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Memex,
    ApplicationRecord::Copilot,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Notify,
    optional: true, only: [:checks]

  depends_on_clusters ApplicationRecord::Mysql5,
    optional: false, only: [:changes_since_last_review, :patch]

  depends_on_clusters ApplicationRecord::Copilot,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Notify,
    ApplicationRecord::RepositoriesActionsChecks,
    ApplicationRecord::NotificationsEntries,
    optional: true, only: [:findings]

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Iam,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Permissions,
    optional: false, only: [:timeline_more_items]

  depends_on_clusters ApplicationRecord::Copilot,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Notify,
    ApplicationRecord::RepositoriesActionsChecks,
    ApplicationRecord::NotificationsEntries,
    optional: true, only: [:timeline_more_items]

  depends_on_clusters ApplicationRecord::RepositoriesActionsChecks,
    optional: false, only: [:new]

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    optional: true, only: [:new]

  depends_on_clusters ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Iam,
    optional: false, only: [:open_with_menu]

  depends_on_clusters ApplicationRecord::Billing,
    ApplicationRecord::Mysql5,
    optional: true, only: [:open_with_menu]

  depends_on_clusters ApplicationRecord::Copilot,
    optional: true, only: [:open_with_menu]

  depends_on_clusters ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Repositories,
    optional: false, only: [:deferred_commits_data]

  depends_on_clusters ApplicationRecord::RepositoriesActionsChecks,
    ApplicationRecord::Spokes,
    optional: true, only: [:deferred_commits_data]

  depends_on_clusters(
    ApplicationRecord::Ballast,
    ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::Iam,
    ApplicationRecord::IamAbilities,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Permissions,
    ApplicationRecord::Repositories,
    optional: false,
    only: [:post_merge]
  )
  depends_on_clusters(
    ApplicationRecord::Copilot,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Notify,
    ApplicationRecord::NotificationsSummaries,
    ApplicationRecord::RepositoriesActionsChecks,
    optional: true,
    only: [:post_merge]
  )
  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Billing,
    ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::Iam,
    ApplicationRecord::IamAbilities,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::NotificationsEntries,
    ApplicationRecord::Notify,
    ApplicationRecord::Permissions,
    ApplicationRecord::Repositories,
    ApplicationRecord::RepositoriesActionsChecks,
    ApplicationRecord::Spokes,
    ApplicationRecord::Pages,
    optional: false, only: [:dashboard]

  depends_on_clusters ApplicationRecord::Memex,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Copilot,
    ApplicationRecord::Permissions,
    optional: true, only: [:dashboard]

  depends_on_clusters ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Notify,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Mysql5,
    ApplicationRecord::Repositories,
    ApplicationRecord::RepositoriesPushes,
    optional: false, only: [:overview]

  depends_on_clusters ApplicationRecord::Ballast,
    ApplicationRecord::Billing,
    ApplicationRecord::Collab,
    ApplicationRecord::Configurations,
    ApplicationRecord::Iam,
    ApplicationRecord::IamAbilities,
    ApplicationRecord::IssuesPullRequests,
    ApplicationRecord::Memex,
    ApplicationRecord::Mysql1,
    ApplicationRecord::Mysql2,
    ApplicationRecord::Mysql5,
    ApplicationRecord::NotificationsEntries,
    ApplicationRecord::Notify,
    ApplicationRecord::Permissions,
    ApplicationRecord::Repositories,
    ApplicationRecord::RepositoriesActionsChecks,
    ApplicationRecord::RepositoriesPushes,
    ApplicationRecord::Spokes,
    optional: false, only: [:show_partial]

  depends_on_clusters ApplicationRecord::Copilot,
    only: [:show_partial], optional: true

  SHOW_FEATURES = [
    :auto_merge,
    :cap_two_factor_filter,
    :copilot_coding_guidelines,
    :merge_queue,
    :merge_queue_extra_branch_protection_settings,
    :previewable_form_component,
    :slash_commands,
    :display_comment_actions,
    :may_post_comment_actions,
    :prx_files,
    :prx_files_opt_out_by_default,
    :reactions_position,
    :prx_comment_outside_the_diff,
    :prx_async_line_outside_diff,
    :remove_side_from_thread_reply,
    :improve_fragile_layout_for_absolute_time,
    :prs_voltron_graceful_timeout_nine,
    :prs_voltron_graceful_timeout_eight,
    :prs_voltron_graceful_timeout_seven,
    :prs_voltron_graceful_timeout_six,
    :prs_voltron_graceful_timeout_five,
    :prs_voltron_graceful_timeout_four,
    :prs_voltron_graceful_timeout_testing,
    :skip_repo_access_checks_for_participants,
    :prs_defer_participants,
    :prs_overview_react,
    :prs_overview_default,
  ].freeze

  # The following actions do not require conditional access checks, enforcement is done with custom behavior within each of these methods:
  # - dashboard: serves `/pulls`, not consistently scoped to an organization.
  #   Enforcement may be required but should be done inline.
  ACTIONS_EXCLUDED_FROM_CAP_CHECKS = %w(dashboard)

  PULL_REQUEST_INDEX_TAG_FILTER_SYMBOLS = [:label, :milestone, :author, :assignee, :review, :project, :sort, :open, :closed]

  rate_limit_requests \
    only: [:dashboard],
    max: :issues_dashboard_without_rate_limit_max,
    ttl: 1.minute,
    key: :issues_dashboard_rate_limit_key,
    if: :issues_dashboard_without_referer_limits_enabled?,
    at_limit: :issues_dashboard_rate_limit_at_limit

  rate_limit_requests \
    only: [:index],
    max: :issues_index_rate_limit_max,
    ttl: 1.minute,
    key: :issues_index_rate_limit_key,
    if: :issues_index_rate_limiting_enabled?,
    at_limit: :issues_index_rate_limit_at_limit

  rate_limit_requests \
    only: [:show],
    max: PR_SHOW_ANONYMOUS_RATE_LIMIT_MAX,
    ttl: GitHub::RateLimitedRequest::DEFAULT_RATE_LIMIT_TTL, # 1 hour
    if: :use_new_anonymous_rate_limit?,
    key: :default_rate_limit_key

  COMMITS_TO_FETCH_DATA_FOR_AT_A_TIME = 10
  DEFAULT_TIMELINE_ITEMS_PAGE_LIMIT = 20

  preload_features SHOW_FEATURES, only: :show
  preload_features [:actions_check_annotation_read_limit], only: :checks

  preload_features [
    :apply_prx_limits,
    :prx_files,
    :pr_files_anon,
    :prx_files_opt_out_by_default,
    :detect_homoglyphs,
  ], only: :files

  preload_features [
    :apply_prx_limits,
    :prx_files,
    :prx_files_opt_out_by_default,
    :detect_homoglyphs,
    :pull_requests_show_outdated_comments_in_review_panel
  ], only: :changes

  # Bulk update a set of issues state, assignee, milestone or labels.
  #
  # PUT /github/github/issues/triage
  #
  # issues    - Array of Issue numbers or a String search query.
  # assignee  - A User ID to assign the issues to or blank to unassign.
  # milestone - A Milestone ID to set the issues to or black to unset.
  # labels    - A Hash of Label IDs with values '1' or "0" to add or remove.
  # state     - A string "open" or "closed" to assign to issues.
  # projects  - A Hash of Project IDs with values 'on' to add.
  # archive   - A string "true" or "false" to archive or unarchive pull requests.
  def triage # rubocop:todo GitHub/UseRestfulActions
    case params[:issues]
    when String
      issues = Issue::SearchResult.search(
        query:             params[:issues],
        repo:              current_repository,
        current_user:      current_user,
        remote_ip:         T.must(request).remote_ip,
        tags:              default_search_tags,
        context:           "#{T.must(self.class.name).demodulize.underscore}-#{__method__}-#{pulls_only? ? "pull_requests" : "issues"}",
      )[:issues]
    when Array
      issues = current_repository.issues.where("issues.number IN (?)", params[:issues]).to_a # domain-isolation-query-violation:ignore:packages/issues (SELECT)
    else
      issues = []
    end

    unless current_repository.has_issues?
      issues = issues.select(&:pull_request?)
    end

    # copy over params for IssueTriageJob
    job_params = {}
    job_params[:state] = params[:state] if params.key?(:state)
    job_params[:milestone] = params[:milestone] if params.key?(:milestone)
    job_params[:assignee] = params[:assignee] if params.key?(:assignee)
    job_params[:clear_assignees] = params[:clear_assignees] if params.key?(:clear_assignees)

    if params[:assignees].respond_to?(:each)
      job_params[:assignees] = {}
      params[:assignees].each { |k, v| job_params[:assignees][k] = v }
    end

    if params[:labels].respond_to?(:each)
      job_params[:labels] = {}
      params[:labels].each { |k, v| job_params[:labels][k] = v }
    end

    if params[:projects].respond_to?(:each)
      job_params[:projects] = {}
      params[:projects].each { |k, v| job_params[:projects][k] = v }
    end

    job_params[:archive] = params[:archive] if FeatureFlag.vexi.enabled?(:archive_pull_request, current_repository, default: false) && params.key?(:archive)

    status = Issues::JobStatus.create(repository_id: current_repository.id)

    IssueTriageJob.perform_later(status.id, issues.map(&:id), T.must(current_user).id, job_params)

    if T.must(request).xhr?
      render json: { job: { url: job_status_url(status.id) } }
    else
      redirect_to :back
    end
  end

  # Sets the milestone for one or many issues.
  #
  # Expected params:
  #
  #   :milestone - The Milestone's id you wish to set. Optionally "clear" if
  #                you wish to clear the current milestones.
  #   :new_milestone - A title of a new milestone to create.
  #   :issues - An Array of Issue numbers.
  #
  # If :new_milestone is sent, :milestone is ignored and a *new* milestone
  # is created (without a due date) and the issue(s) are assigned to the new
  # milestone.
  #
  # For AJAX requests, JSON is returned with the HTML of the infobar and
  # context pane partials.
  def set_milestone # rubocop:todo GitHub/UseRestfulActions
    return render_404 unless current_issue.present?
    if params[:milestone] == "new"
      milestone = create_milestone(params[:milestone_title])
      return head :unprocessable_entity unless milestone
    elsif params[:milestone] == "clear"
      milestone = nil
    else
      milestone = current_repository.milestones.find(params[:milestone])
    end

    issue = current_issue
    if issue.milestone != milestone
      begin
        Issue.transaction do # domain-isolation-query-violation:ignore:packages/issues (UPDATE)
          issue.milestone = milestone
          issue.save! # domain-isolation-query-violation:ignore:packages/issues (UPDATE)
        end
      rescue GitHub::Prioritizable::Context::LockedForRebalance
        GitHub.dogstats.increment("milestones.exceptions.locked_for_rebalance", { tags: ["context:issues_controller.set_milestone"] })
        return render status: 503, plain: "Sorry! This milestone is temporarily locked for maintenance. Please try again."
      end
    end

    @issue = issue
    respond_to do |format|
      format.html do
        render partial: "issues/sidebar/show/milestone", locals: { issue: issue }
      end
    end
  end

  # Public: Locks an issue publicly with a reason to not to comment to.
  def lock # rubocop:todo GitHub/UseRestfulActions
    reason = params[:reason].present? ? params[:reason] : nil

    unless current_issue.locked?
      current_issue.lock(current_user, reason) # domain-isolation-query-violation:ignore:packages/issues (SELECT, UPDATE)
    end
    redirect_to :back
  end

  # Public: Unlocks an issue publicly, this needs no reason.
  def unlock # rubocop:todo GitHub/UseRestfulActions
    if current_issue.locked?
      current_issue.unlock(current_user) # domain-isolation-query-violation:ignore:packages/issues (SELECT, UPDATE)
    end
    redirect_to :back
  end

  # Public: Archives a pull request. Closes, locks, and marks it as archived.
  def archive # rubocop:todo GitHub/UseRestfulActions
    return render_404 unless FeatureFlag.vexi.enabled?(:archive_pull_request, current_repository, default: false)
    pull = current_issue&.pull_request
    return render_404 unless pull

    pull.archive!(current_user, current_issue)
    redirect_to :back
  end

  # Public: Unarchives a pull request. Removes the archived flag.
  def unarchive # rubocop:todo GitHub/UseRestfulActions
    return render_404 unless FeatureFlag.vexi.enabled?(:archive_pull_request, current_repository, default: false)
    pull = current_issue&.pull_request
    return render_404 unless pull

    pull.unarchive!(current_user)
    redirect_to :back
  end

  def linked_closing_reference # rubocop:todo GitHub/UseRestfulActions
    return render_404 unless current_issue

    close_issue_references = CloseIssueReference.viewable_for(viewer: current_user, issue: current_issue) # domain-isolation-query-violation:ignore:packages/issues (SELECT)

    return render_404 unless close_issue_references.size == 1

    if current_issue.pull_request?
      issue = close_issue_references.first.issue
      GlobalInstrumenter.instrument("browser.issue_cross_references.click",
                                    reference_location: params[:reference_location],
                                    user_id: current_user,
                                    issue_id: issue.id,
                                    pull_request_id: current_issue.pull_request_id)

      redirect_to issue_path(issue)
    else
      pr = close_issue_references.first.pull_request
      GlobalInstrumenter.instrument("browser.issue_cross_references.click",
                                    reference_location: params[:reference_location],
                                    user_id: current_user,
                                    issue_id: current_issue.id,
                                    pull_request_id: pr.id)

      redirect_to pull_request_path(pr)
    end
  end

  def dismiss_first_contribution_prompt # rubocop:todo GitHub/UseRestfulActions
    return head :not_found unless current_issue.present?
    return head :not_found unless current_issue.show_first_contribution_prompt?(current_user)
    current_issue.dismiss_first_contribution_prompt
    head :ok
  end

  def dismiss_first_contribution_prompt_and_redirect # rubocop:todo GitHub/UseRestfulActions
    return render_404 unless current_issue.present?
    return render_404 unless current_issue.show_first_contribution_prompt?(current_user)
    current_issue.dismiss_first_contribution_prompt
    redirect_to community_path
  end

  def update
    return head 404 unless current_issue.present?
    return head 200 unless logged_in? && !blocked_by_owner?
    original_unsafe_params = indifferent_params

    if params[:pull_request]
      unsafe_params = original_unsafe_params[:pull_request]
    else
      unsafe_params = original_unsafe_params.fetch :issue, {}
    end

    unsafe_params.merge(body: params[:comment]) if params[:comment]
    safe_issue_params = unsafe_params.slice(
      :milestone_id,
      :title,
      :body,
    )

    valid = T.let(true, T.untyped)
    text = T.let(nil, T.untyped)
    issue = current_issue
    issue.skip_hydro_update_event_instrumentation = true
    previous_title = issue.title
    previous_body = issue.body
    update_issue_orchestration = T.let(nil, T.untyped)

    # prevent updates from stale data
    if stale_model?(current_issue)
      return render_stale_error(model: current_issue, error: "Could not edit issue. Please try again.", path: issue_path(current_issue))
    end

    if current_user_can_push? && safe_issue_params[:milestone_id] == "clear"
      safe_issue_params[:milestone_id] = nil
    else
      safe_issue_params.delete(:milestone_id)
    end

    issue.skip_create_issue_orchestration = true
    issue.skip_update_issue_orchestration = true

    IssueOrchestration.transaction do
      issue_params_except_body = safe_issue_params.except(:body)
      valid = issue_params_except_body.empty? || issue.update(issue_params_except_body) # domain-isolation-query-violation:ignore:packages/issues (UPDATE)

      async_mark_thread_as_read issue

      if operation = TaskListOperation.from(params[:task_list_operation])
        text = operation.call(issue.body)
        valid = issue.update_body(text, current_user) if text

      elsif safe_issue_params[:body]
        valid = issue.update_body(safe_issue_params[:body], current_user)
      end

      if valid
        update_issue_orchestration = IssueOrchestration.update_issue!(actor: current_user, issue: issue)
      end
    end

    if valid
      update_issue_orchestration.execute! if update_issue_orchestration

      issue.instrument_hydro_update_event(
        previous_title: previous_title,
        previous_body: previous_body,
      )
      track_issue_edits_from_project_board(edited_fields: safe_issue_params.keys)
    end

    if T.must(request).xhr?
      respond_to do |format|
        format.json do
          if valid
            errors = issue.errors.map { |error| error.message }
            render json: issue_update_payload(issue.reload, errors) # domain-isolation-query-violation:ignore:packages/issues (SELECT)
          else
            render json: { errors: issue.errors.full_messages }, status: :unprocessable_entity
          end
        end
      end
    else
      respond_to do |format|
        format.html { redirect_to issue_path(issue) }
      end
    end
  end

  def index
    return safe_redirect_to(index_flow.redirect_path) if index_flow.needs_redirection?

    # Always set the controller tag to pull_requests since we're in the pull requests controller
    GitHub::TaggingHelper.override_controller_tag(env: env, controller: "pull_requests")
    GitHub.current_span&.set_attribute(GitHub::TaggingHelper::CONTROLLER_TAG, "pull_requests")

    query = index_flow.query
    self.parsed_issues_query = Search::Queries::IssueQuery.parse(query, current_user)

    search_query = filter_archived_prs(parsed_issues_query)

    query_error  = false
    issues       = []
    open_count   = 0
    closed_count = 0

    begin
      # When searching exclusively for pull requests, we do not need to prefill the comment counts.
      # Once a search happens exclusively in pull requests, there is no need to load the issues counts.
      # the `IssueListItem` in app/view_models/issues/issue_list_item.rb:154 takes care of a possible fallback and memorization.
      tags = query_parsed_search_tags

      result = Issue::SearchResult.search( # domain-isolation-query-violation:ignore:packages/issues (SELECT)
        query:                search_query,
        current_user:         current_user,
        remote_ip:            T.must(request).remote_ip,
        repo:                 current_repository,
        force_pulls:          index_flow.force_pulls?,
        pulls_index_request:  index_flow.pulls_index_request?,
        page:                 params[:page],
        show_spam_to_staff:   current_user&.show_spammy_issues_to_staff_enabled?,
        tags:                 tags,
        context:              "#{T.must(self.class.name).demodulize.underscore}-#{__method__}-pull_requests",
      )

      issues       = result[:issues]
      open_count   = result[:open_count]
      closed_count = result[:closed_count]
    rescue ElastomerClient::Client::Error => boom
      Failbot.push app: "github-user"
      Failbot.report boom
      query_error  = true
    end

    # don’t show pull requests on the index page when pull requests are disabled
    unless PullRequestActivationConfig.new(current_repository).pull_requests_enabled?
      issues       = []
      open_count   = 0
      closed_count = 0
    end

    # disallow robots if labels or milestone is given
    label_or_milestone = parsed_issues_query.assoc(:label) || parsed_issues_query.assoc(:milestone)
    if robot? && label_or_milestone
      return render_404
    end

    strip_analytics_query_string

    milestones_count = current_repository.milestones.open_milestones.count
    labels_count = current_repository.labels.count

    respond_to do |format|
      format.html do
        track_time(tags: ["method:index", "step:render"]) do
          render "issues/index", locals: {
            issues: issues,
            pulls_only: true,
            query: query,
            query_error: query_error,
            open_count: open_count,
            closed_count: closed_count,
            milestones_count: milestones_count,
            labels_count: labels_count,
            tags: query_parsed_search_tags,
            render_issue_react_opt_in: false,
            page: params[:page]
          }
        end
      end
    end
  end

  def new
    if FeatureFlag.vexi.enabled?(:pull_request_templates, current_user, default: false) || FeatureFlag.vexi.enabled?(:pull_request_templates, current_repository, default: false)
      safe_redirect_to compare_path(current_repository, params[:range])
    else
      safe_redirect_to compare_path(current_repository, params[:range], expand: true)
    end
  end

  def create
    repo = current_repository
    return render_404 unless repo
    return if reject_bully?
    GitHub.context.push(spamurai_form_signals: spamurai_form_signals)

    unsafe_params = T::unsafe(params).permit!.to_h.with_indifferent_access
    unsafe_pull_request_params = unsafe_params[:pull_request]

    issue = build_issue unsafe_params

    if issue.present?
      issue.title = unsafe_pull_request_params[:title] unless issue.title.present?
      issue.body = unsafe_pull_request_params[:body] unless issue.body.present?
    end

    options = unsafe_params.slice :base, :head
    options[:user] = current_user
    options[:issue] = issue
    options[:collab_privs] = !!unsafe_params[:collab_privs]
    options[:reviewer_user_ids] = unsafe_params[:reviewer_user_ids]
    options[:reviewer_team_ids] = unsafe_params[:reviewer_team_ids]
    options[:issue_memex_project_ids] = unsafe_params[:issue_memex_project_ids]

    options[:draft] = unsafe_params[:draft] == "on"
    PullRequests::UserSettings.new(current_user, repo).set_default_pull_requests_to_draft(options[:draft])

    if unsafe_params[:head_repo].present?
      head_repo = Repository.with_name_with_owner(unsafe_params[:head]&.split(":")&.first, params[:head_repo])
      if head_repo && current_repository.id != head_repo.id && current_repository.source_id == head_repo.source_id
        options[:head_repo] = head_repo if head_repo.readable_by?(current_user)
      end
    end

    begin
      @pull_request = PullRequest.create_for!(repo, options)
      @issue        = @pull_request.issue

      begin
        track_time(tags: ["method:create", "step:add_to_memex_projects"]) do
          @issue.add_to_memex_projects!(
            options[:issue_memex_project_ids],
            @pull_request,
            options[:user]
          )
        end
      rescue GitHub::Prioritizable::Context::LockedForRebalance, GitHub::Prioritizable::RebalanceRequiredError
        selected_project_count = (params[:issue_memex_project_ids] || {}).values.count { |v| v == "on" }
        GitHub.dogstats.increment("memex_project_items.exceptions.locked_for_rebalance", { tags: ["context:pull_requests_controller.create"] })
        flash[:error] = "Sorry! We encountered an error and the pull request was not added to the selected #{"project".pluralize(selected_project_count)}. Please try again."
      rescue MemexProjectItem::ProjectLimitReachedError => error
        GitHub.dogstats.increment("memex_project_items.exceptions.project_limit_reached", { tags: ["context:pull_requests_controller.create"] })
        projects_with_errors_count = error.memex_projects_with_errors.count
        flash[:error] = "Sorry! We were unable to add the pull request to the selected #{"project".pluralize(projects_with_errors_count)}. Projects cannot have more than #{error.memex_projects_with_errors.first&.items_limit} items."
      end

      if params[:create_stack] == "1"
        add_new_pull_request_to_stack(@pull_request)
      end

      if params[:show_onboarding_guide_tip].present?
        next_url = pull_request_path(@pull_request, repo)
        redirect_to "#{next_url}?show_onboarding_guide_tip=true"
        return
      end

      redirect_to pull_request_path(@pull_request, repo)
    rescue ActiveRecord::RecordInvalid => e
      flash[:error] = "Pull request creation failed. #{human_failure_message(e)}"
      range = [options[:base], options[:head]].compact.join("...")
      redirect_to compare_path(repo, range, expand: true, stack: params[:create_stack].present?)
    end
  end

  sig { params(new_pull: PullRequest).void }
  private def add_new_pull_request_to_stack(new_pull)
    return unless PullRequests::Stacks.enabled?(current_repository)

    previous_pull = PullRequest.open_pulls.find_by(
      repository: current_repository,
      head_ref: new_pull.base_ref,
    )

    if previous_pull.nil?
      flash[:error] = "Cannot find another PR to build a stack with."
      return
    end

    result = PullRequests::Stacks.create_or_append(bottom: previous_pull, top: new_pull)
    case result
    when PullRequests::Stacks::Error
      flash[:error] = "Cannot stack on top of PR ##{previous_pull.number}: #{result.message}"
    when PullRequests::Stacks::CreateOrAppend::Service::Success
      # Success: no-op
    else
      T.absurd(result)
    end
  rescue => e
    Failbot.report(e)
    flash[:error] = "Pull request could not be added to stack, an unexpected error occurred."
  end

  def edit_form # rubocop:todo GitHub/UseRestfulActions
    return render_404 unless T.must(request).xhr?
    return render_404 if current_issue.nil?
    unless current_issue.editable_by?(current_user)
      head :forbidden
      return
    end

    render Comments::EditForm::EditFormComponent.new(
      comment: current_issue,
      comment_context: params[:comment_context],
      textarea_id: params[:textarea_id],
      slash_commands_enabled: T.must(current_user).slash_commands_enabled?,
      slash_commands_surface: current_issue.pull_request? ? SlashCommands::PULL_REQUEST_BODY_SURFACE : SlashCommands::ISSUE_BODY_SURFACE,
      current_repository: current_repository
    ), layout: false
  end

  def actions_menu # rubocop:todo GitHub/UseRestfulActions
    return render_404 unless T.must(request).xhr?
    return render_404 unless current_issue

    current_issue.preload_viewer_attributes(current_user)

    render partial: "comments/comment_header_details_menu", locals: {
      comment: current_issue,
      viewer: current_user,
      repository: current_repository,
      form_path: issue_comment_path(
        current_issue.repository.owner.display_login,
        current_issue.repository.name,
        current_issue.id
      ),
      issue_path: show_pull_request_path(
        current_repository.owner,
        current_repository,
        current_issue),
      href: params[:href]
    }
  end

  VALID_SHOW_MENU_CONTENT_TEMPLATES = [
    "issues/filters/assigns_content",
    "issues/filters/authors_content",
    "issues/filters/labels_content",
    "issues/filters/milestones_content",
    "issues/filters/orgs_content",
    "issues/filters/projects_content",
    "issues/triage/actions_content",
    "issues/triage/assigns_content",
    "issues/triage/labels_content",
    "issues/triage/projects_content",
    "issues/triage/milestones_content",
  ].freeze

  def show_menu_content # rubocop:todo GitHub/UseRestfulActions
    partial = params[:partial]
    authorization_required if current_repository

    return head :not_found unless VALID_SHOW_MENU_CONTENT_TEMPLATES.include?(partial)

    track_time(metric: "view.dist.time", tags: ["subject:issue", "action:show_partial_render"]) do
      respond_to do |format|
        format.html do
          case partial
          when "issues/filters/assigns_content"
            query = params_or_default_query_string
            render partial: "issues/filters/assigns_content", layout: false, locals: {
              issue: current_issue,
              query: query,
              pulls_only: true,
            }
          when "issues/filters/authors_content"
            query = params_or_default_query_string
            render partial: "issues/filters/authors_content", layout: false, locals: {
              issue: current_issue,
              query: query,
              pulls_only: true,
            }
          when "issues/filters/labels_content"
            query = params_or_default_query_string
            render partial: "issues/filters/labels_content", layout: false, locals: {
              issue: current_issue,
              query: query,
              pulls_only: true,
            }
          when "issues/filters/milestones_content"
            query = params_or_default_query_string
            render partial: "issues/filters/milestones_content", layout: false, locals: {
              issue: current_issue,
              query: query,
              pulls_only: true,
            }
          when "issues/filters/orgs_content"
            query = params_or_default_query_string
            render partial: "issues/filters/orgs_content", layout: false, locals: {
              issue: current_issue,
              query: query,
              pulls_only: true,
            }
          when "issues/filters/projects_content"
            query = params_or_default_query_string
            render partial: "issues/filters/projects_content", layout: false, locals: {
              issue: current_issue,
              query: query,
              pulls_only: true,
            }
          when "issues/triage/actions_content"
            render partial: "issues/triage/actions_content", layout: false
          when "issues/triage/assigns_content"
            render partial: "issues/triage/assigns_content", layout: false
          when "issues/triage/labels_content"
            render partial: "issues/triage/labels_content", layout: false
          when "issues/triage/projects_content"
            render partial: "issues/triage/projects_content", layout: false
          when "issues/triage/milestones_content"
            render partial: "issues/triage/milestones_content", layout: false
          end
        end
      end
    end
  end

  VALID_SHOW_PARTIAL_TEMPLATES = [
    "issues/convert_to_discussion_dialog",
    "issues/form_actions",
    "issues/sidebar",
    "issues/sidebar/assignees_menu_content",
    "issues/sidebar/labels_menu_content",
    "issues/sidebar/milestone_menu_content",
    "issues/sidebar/new/assignees",
    "issues/sidebar/new/labels",
    "issues/sidebar/new/milestone",
    "issues/sidebar/project_card_move",
    "issues/sidebar/projects_menu_content",
    "issues/sidebar/show/assignees", # Only used in test?
    "issues/sidebar/show/labels",
    "issues/sidebar/show/projects",
    "issues/sidebar/show/milestone",
    "issues/state_button_wrapper",
    "issues/timeline",
    "issues/title",
    "projects/card_issue_details_title",
    "projects/card_issue_details_title_icon",
    "users/participants",
    # For splitting pull requests live updates
    "pull_requests/sidebar/show/reviewers",
  ]

  def show_partial # rubocop:todo GitHub/UseRestfulActions
    partial = params[:partial]
    # Since we have renamed `projects_menu_content_fast` to `projects_menu_content` we need to check both as existing sessions may use both.
    partial = "issues/sidebar/projects_menu_content" if partial == "issues/sidebar/projects_menu_content_fast"

    return head :not_found unless VALID_SHOW_PARTIAL_TEMPLATES.include?(partial)

    GitHub.tracer.in_span(
      "pull_requests_controller#show_partial: #{partial}", kind: :internal
    ) do
      milestone_partial = "issues/sidebar/new/milestone"
      if T.must(request).post? && milestone_partial == partial && params[:milestone] == "new"
        params[:milestone] = create_milestone(params[:milestone_title])
      end

      track_time(tags: ["method:show_partial", "partial:#{partial}", "step:build_issue"]) do
        @issue = params[:id] ? current_issue : build_issue(indifferent_params)
      end

      track_time(tags: ["method:show_partial", "partial:#{partial}", "step:render"]) do
        return head :not_found if @issue.nil?
        return head :not_found unless @issue.new_record? || @issue.pull_request? || current_repository.has_issues?

        respond_to do |format|
          format.html do
            locals = {
              issue: @issue,
              deferred_content: false,
              inline: params[:inline] == "true",
              sticky: params[:sticky] == "true"
            }

            if partial == "issues/sidebar/project_card_move"
              # The show_columns_menu param can be passed to override the show_columns_menu local being made true by default.
              # Passing false prevents showing the caret for the column dropdown in the projects sidebar.
              # Currently limited to issues/sidebar/project_card_move partial and others will need to be added to this list to use it.
              show_columns_menu = true unless params.has_key?(:show_columns_menu) && params[:show_columns_menu] != "true"
              locals = locals.merge({ show_columns_menu: show_columns_menu })
            end

            if partial == "issues/title"
              locals[:tracking_issues] = tracking_issues
            end

            if partial == "issues/checklist_progress"
              locals[:render_mode] = params[:render_mode]
            end

            if partial == "issues/convert_to_discussion_dialog"
              locals[:discussion_categories] = current_repository.available_discussion_categories
            end

            if partial == "issues/sidebar/labels_menu_content"
              locals[:use_label_typeahead] = current_repository&.feature_flag_enabled?(:issues_labels_typeahead, default: false)
            end

            if partial == "issues/sidebar/projects_menu_content" && params[:tasklist_id]
              locals[:project_picker_result_id] = "project-picker-results-#{params[:tasklist_id]}-#{current_repository.name}-#{current_issue.number}"
            end

            if partial == "pull_requests/sidebar/show/reviewers"
              locals[:pull_request] = @issue.pull_request
            end

            render partial: partial, layout: partial_fragment_layout, object: @issue, locals: locals
          end

          format.json do
            if partial == "issues/sidebar/labels_menu_content"
              timer = Timer.start
              type_ahead_enabled = params[:typeAhead].present?

              if type_ahead_enabled
                search_query = params[:q].to_s
                sanitized_query = ActiveRecord::Base.sanitize_sql_like(search_query)

                sorted_labels = current_repository.sorted_labels_containing_keyword(issue_or_pr: @issue, contains: sanitized_query)
              else
                sorted_labels = current_repository.sorted_labels(issue_or_pr: @issue, cache_label_html: true)

                # If this code path gets hit, it means we've pre-rendered labels already so don't need to return it.
                sorted_labels = sorted_labels - @issue.labels
              end

              output = sorted_labels.map do |label|
                {
                  id: label.id,
                  name: label.name,
                  color: label.color,
                  htmlName: label.name_html,
                  selected: @issue.labels.include?(label),
                  description: label.description
                }
              end

              render json: { labels: output }
              output
            elsif "issues/sidebar/assignees_menu_content" == partial
              return head :not_found unless @issue.assignable_by?(actor: current_user) || @issue.triageable_by?(current_user)

              timer = Timer.start
              sorted_assignees = []
              type_ahead_enabled = params[:typeAhead].present?
              # If type-ahead header isn't present, we assume the front-end JS isn't updated yet, so we
              # assume old behaviour and fall-back.
              if type_ahead_enabled
                search_query = params[:q].to_s

                if search_query.blank?
                  return render json: { users: [] }
                else
                  sorted_assignees = @issue.filtered_assignees_list(current_user, search_query)
                end
                sorted_assignees.delete(current_user)

                # Participants isn't guaranteed to be correct, in the event of PR#New, this doesn't populate with assignees
                # So we need to filter both to ensure we aren't returning duplicated results.
                sorted_assignees = sorted_assignees - @issue.participants - @issue.assignees
              else
                sorted_assignees = @issue.sorted_assignees_list(current_user: current_user)

                # If this code path gets hit, it means we've pre-rendered the assignees already so don't need to return it.
                sorted_assignees = sorted_assignees - @issue.assignees
              end

              # note: this code path is needed to show Copilot in the pr#show where the assignee picker is using this partial
              # for the issue#show that is powered by React, this is different code path
              # only show bot as assignee if it's authored by the bot AND it's not already assigned
              bot_id = @issue.user_id
              if bot_id && @issue.assignable_bot_ids(current_user).include?(bot_id)
                # Only add to suggestions if the bot is not already assigned
                unless @issue.assignees.map(&:id).include?(bot_id)
                  assigned_bot = Bot.find_by(id: bot_id)
                  sorted_assignees.unshift(assigned_bot).uniq! if assigned_bot
                end
              end

              user_data = track_time(metric: "assignees.prepare_users.dist.time") do
                sorted_assignees.map do |user|
                  profile_name = user.safe_profile_name
                  user_status = user.user_status
                  if !user_status&.expired? && user_status&.limited_availability?
                    profile_name = "#{profile_name} (busy)"
                  end

                  {
                    id: user.id,
                    name: profile_name,
                    login: user.display_login_legacy,
                    selected: @issue.assigned_to?(user),
                    avatar: user.primary_avatar_url(60),
                    class: helpers.avatar_class_names(user),
                  }
                end
              end

              output = track_time(metric: "assignees.render.dist.time", tags: []) do
                render json: { users: user_data }
              end

              timer.stop
              tags = ["type_ahead_enabled:#{type_ahead_enabled}"]

              GitHub.dogstats.distribution("issues_controller.assignees_menu_content.dist.time", timer.elapsed_ms, tags: tags)

              output
            else
              head :bad_request
            end
          end
        end
      end
    end
  end

  def files # rubocop:todo GitHub/UseRestfulActions
    unsafe_params = T::unsafe(params).permit!.to_h.with_indifferent_access

    redirect_or_error = ensure_valid_pull_request

    if performed?
      return redirect_or_error
    end

    range = unsafe_params[:range]
    mode = unsafe_params[:mode]

    return render_pull_requests_react(pull: @pull, range: range, mode: mode) if should_render_react_files_changed?

    stats.entity = @pull

    set_hovercard_subject(@pull)

    if range
      oid1, oid2 = parse_show_range_oid_components!(@pull, range)

      expected_canonical_range = oid1 ? "#{oid1}..#{oid2}" : "#{oid2}"
      if range != expected_canonical_range
        return redirect_to(range: expected_canonical_range)
      end

      @comparison = @pull.historical_comparison
      merge_base_oid = @comparison.compare_repository.best_merge_base(@pull.base_sha, oid2)

      if merge_base_oid.nil?
        return render "pull_requests/orphan_commit", status: :not_found, locals: { oid2: oid2 }
      end

      oid1 ||= @pull.compare_repository.best_merge_base(oid2, merge_base_oid) if merge_base_oid
      unless @pull_comparison = PullRequest::Comparison.find(pull: @pull, start_commit_oid: oid1, end_commit_oid: oid2, base_commit_oid: merge_base_oid, viewer: current_user)
        raise PullRequests::Errors::BadRange
      end

      load_diff
    else
      @comparison = @pull.comparison

      return if pjax? && !stale?(@pull, template: false)

      start_oid, end_oid = @pull.merge_base, @pull.head_sha
      if start_oid && end_oid
        begin
          start_commit, end_commit = @pull.compare_repository.commits.find([start_oid, end_oid])
          @pull_comparison = PullRequest::Comparison.new(pull: @pull, start_commit: start_commit, end_commit: end_commit, base_commit: start_commit, viewer: current_user)

          load_diff
        rescue GitRPC::ObjectMissing
        end
      end
    end

    if @pull_comparison && logged_in?
      async_mark_comparison_as_seen(@pull_comparison, user: T.must(current_user))
      mark_pull_notification_as_read @pull.issue
    end

    stats.record_distribution("prepare_and_highlight") do
      prepare_for_rendering_files(pull_comparison: @pull_comparison)
    end

    override_analytics_location "/<user-name>/<repo-name>/pull_requests/show/files"

    respond_to do |format|
      format.html do
        if logged_in?
          @current_review = @pull.latest_pending_review_for(current_user)
        end

        if @pull_comparison.nil?
          render "pull_requests/files_unavailable"
        else
          file_count = @pull_comparison.diffs.changed_files
          file_tree_available = file_tree_available?(
            file_count: file_count,
          )

          render "pull_requests/files", locals: {
            show_checks_status: GitHub.actions_enabled?,
            file_count: file_count,
            file_tree_available: file_tree_available,
            visibility: codespaces_menu_visibility
          }
        end
      end
    end
  rescue GitHub::Diff::Parser::UnrecognizedText => error
    render "pull_requests/unrecognized_diff_text", status: :not_found, locals: { pull: @pull }
  rescue PullRequests::Errors::BadRange
    disable_account_switcher_popover
    render "pull_requests/bad_range", status: :not_found
  end

  def checks # rubocop:todo GitHub/UseRestfulActions
    unsafe_params = T::unsafe(params).permit!.to_h.with_indifferent_access

    redirect_or_error = ensure_valid_pull_request

    if performed?
      return redirect_or_error
    end

    set_hovercard_subject(@pull)

    override_analytics_location "/<user-name>/<repo-name>/pull_requests/show/checks"

    if unsafe_params[:check_run_id] && !@pull.changed_commit_oids.include?(selected_check_run&.head_sha)
      flash[:notice] = "No check run found with ID #{unsafe_params[:check_run_id]} for this pull request."
      redirect_to "#{pull_request_path(@pull)}/checks" and return
    end

    if selected_check_run || params[:sha]
      sha = selected_check_run&.head_sha || params[:sha]
      commit = @pull.changed_commits.find { |commit| commit.oid == sha }

      unless commit
        flash[:notice] = "No commit was found with sha #{sha} for this pull request."
        redirect_to "#{pull_request_path(@pull)}/checks" and return
      end
    end

    return render_pull_requests_react(pull: @pull) if checks_react_enabled?

    respond_to do |format|
      format.html do
        render "checks/show", locals: checks_partial_data(@pull)
      end
    end
  end

  def findings # rubocop:disable GitHub/UseRestfulActions
    redirect_or_error = ensure_valid_pull_request

    if performed?
      return redirect_or_error
    end

    unless FeatureFlag.vexi.enabled?(:copilot_code_review_findings_ui, current_user, default: false)
      return redirect_to gh_show_pull_request_path(@pull)
    end

    set_hovercard_subject(@pull)

    override_analytics_location "/<user-name>/<repo-name>/pull_requests/show/findings"

    render_pull_requests_react(pull: @pull)
  end

  def timeline_more_items # rubocop:todo GitHub/UseRestfulActions
    redirect_or_error = ensure_valid_pull_request
    if performed?
      return redirect_or_error
    end

    return render_404 unless valid_cursors?(params[:before_cursor], params[:after_cursor])

    timeline_owner = PullRequest::ShowLoader.issue_node(
      @pull,
      current_repository,
      current_user,
      cap_filter: cap_filter,
      pagination_params: {
        exclude_item_types: exclude_item_types,
        per_page: params[:timeline_per_page] || DEFAULT_PAGE_SIZE,
        before_cursor: params[:before_cursor],
        after_cursor: params[:after_cursor]
      }
    )

    render PullRequests::PagedTimelineComponent.new(timeline_owner: timeline_owner), layout: component_fragment_layout
  end

  def dashboard # rubocop:todo GitHub/UseRestfulActions
    if dashboard_surface_react_app_enabled?
      return DashboardSurfaceController.dispatch(:index, request, response)
    end

    current_organization = Organization.find_by_login(params[:user]) if params[:user]
    unless required_external_identity_session_present?(target: current_organization)
      render_external_identity_session_required(target: current_organization)
      return
    end

    flow = Issue::ControlFlow.new(
      params:       params,
      pulls_only: true,
      components:   parsed_issues_query,
      current_path: T.must(request).fullpath,
      current_user: current_user,
      exclude_archived: true,
    )
    query = flow.query

    self.parsed_issues_query = Search::Queries::IssueQuery.parse(query, current_user)

    search_query = filter_archived_prs(parsed_issues_query)

    return safe_redirect_to(flow.redirect_path) if flow.needs_redirection?
    tags = query_parsed_search_tags

    result = Issue::SearchResult.search(
      query:             search_query,
      current_user:      current_user,
      remote_ip:         T.must(request).remote_ip,
      user_session:      user_session,
      page:              params[:page],
      tags:              tags,
      context:           "#{T.must(self.class.name).demodulize.underscore}-#{__method__}-pull_requests",
    )

    issues       = result[:issues]
    open_count   = result[:open_count]
    closed_count = result[:closed_count]

    if logged_in?
      GitHub.tracer.in_span("issues#dashboard prefills", kind: :internal) do |_span|
        IssuePrefiller.prefill(issues, current_user: current_user)
        pull_requests = issues.map(&:pull_request).compact
        if pull_requests.any?
          PullRequest.prefill_associations(pull_requests, issues: issues)
          GitHub::PrefillAssociations.prefill_batch_method(pull_requests, :base_branch_rule_evaluator)
        end
      end
    end
    strip_analytics_query_string

    render "issues/dashboard",
      layout: layout_for_turbo_request,
      locals: {
        issues: issues,
        query: query,
        pulls_only: true,
        open_count: open_count,
        closed_count: closed_count,
        applied_tab_filter_name: flow.applied_dashboard_tab_filter_name,
        swe_agent_enabled: Copilot::Public::User.for(T.must(current_user)).swe_agent_enabled?
      }
  end

  def show
    unsafe_params = T::unsafe(params).permit!.to_h.with_indifferent_access

    redirect_or_error = ensure_valid_pull_request

    if performed?
      return redirect_or_error
    end

    stats.entity = @pull

    set_hovercard_subject(@pull)

    mark_pull_notification_as_read @pull.issue

    return render_pull_requests_react(pull: @pull) if conversations_react_enabled?

    respond_to do |format|
      format.html do
        pull_node = stats.record_distribution("fetch_data", include_net: true) do
          create_pull_node(@pull)
        end

        stats.record_distribution("render_content") do
          render "pull_requests/conversation", locals: {
            pull_node: pull_node,
            pull_request: @pull,
            gate_requests: gate_requests_for(pull_request: @pull, user: current_user),
          }
        end
      end

      # At the moment, nothing within the product will request layout data from this
      # endpoint, but for completeness we're responding to the request for JSON.
      # If we ever add a cache time to the query or otherwise invalidate the query data on the
      # client, we'll need to make a direct request to this route.
      format.json do
        render_react_json(payload: layout_data(@pull))
      end
    end
  end

  def layout # rubocop:todo GitHub/UseRestfulActions
    redirect_or_error = ensure_valid_pull_request
    return redirect_or_error if performed?

    respond_to do |format|
      format.html do
        render_404
      end

      format.json do
        render_react_json(payload: layout_data(@pull))
      end
    end
  end

  def overview # rubocop:todo GitHub/UseRestfulActions
    redirect_or_error = ensure_valid_pull_request
    return redirect_or_error if performed?
    return redirect_to(pull_request_path(@pull)) unless overview_react_enabled?

    render_pull_requests_react(pull: @pull)
  end

  def commits # rubocop:todo GitHub/UseRestfulActions
    unsafe_params = T::unsafe(params).permit!.to_h.with_indifferent_access

    redirect_or_error = ensure_valid_pull_request

    stats.entity = @pull

    if performed?
      return redirect_or_error
    end

    set_hovercard_subject(@pull)

    commit_file_view = false

    range = unsafe_params[:range]

    if range
      oid1, oid2 = parse_show_range_oid_components!(@pull, unsafe_params[:range])

      expected_canonical_range = oid1 ? "#{oid1}..#{oid2}" : "#{oid2}"
      if unsafe_params[:range] != expected_canonical_range
        return redirect_to(range: expected_canonical_range)
      end

      commit_file_view = true
      oid1 = current_repository.commits.find(oid2).parent_oids.first

      @comparison = @pull.historical_comparison
      merge_base_oid = @comparison.compare_repository.best_merge_base(@pull.base_sha, oid2)

      if merge_base_oid.nil?
        return render "pull_requests/orphan_commit", status: :not_found, locals: { oid2: oid2 }
      end

      oid1 ||= @pull.compare_repository.best_merge_base(oid2, merge_base_oid) if merge_base_oid
      unless @pull_comparison = PullRequest::Comparison.find(pull: @pull, start_commit_oid: oid1, end_commit_oid: oid2, base_commit_oid: merge_base_oid)
        raise PullRequests::Errors::BadRange
      end

      load_diff
    else
      @comparison = @pull.comparison
    end

    if commit_file_view && @pull_comparison && logged_in?
      async_mark_comparison_as_seen(@pull_comparison, user: T.must(current_user))
      mark_pull_notification_as_read @pull.issue
    end

    if commit_file_view
      prepare_for_rendering_files(pull_comparison: @pull_comparison)
    end

    override_analytics_location "/<user-name>/<repo-name>/pull_requests/show/commits"

    respond_to do |format|
      format.html do
        if commit_file_view
          if logged_in?
            @current_review = @pull.latest_pending_review_for(current_user)
          end

          if @pull_comparison.nil?
            render "pull_requests/files_unavailable"
          else
            file_count = @pull_comparison.diffs.changed_files
            render "pull_requests/files", locals: {
              show_checks_status: GitHub.actions_enabled?,
              file_count: file_count,
              file_tree_available: file_tree_available?(file_count: file_count),
              visibility: codespaces_menu_visibility
            }
          end
        else
          render_pull_requests_react(pull: @pull, range: range)
        end
      end

      format.json do
        render_pull_requests_react(pull: @pull, range: range)
      end

      format.diff { redirect_to commit_path(oid2, current_repository) + ".diff" }
      format.patch { redirect_to commit_path(oid2, current_repository) + ".patch" }
    end
  rescue PullRequests::Errors::BadRange
    disable_account_switcher_popover
    render "pull_requests/bad_range", status: :not_found
  end

  def changes # rubocop:todo GitHub/UseRestfulActions
    unsafe_params = T::unsafe(params).permit!.to_h.with_indifferent_access

    redirect_or_error = ensure_valid_pull_request

    if performed?
      return redirect_or_error
    end

    range = unsafe_params[:range]
    mode = unsafe_params[:mode]

    stats.entity = @pull

    set_hovercard_subject(@pull)

    if logged_in?
      mark_pull_notification_as_read @pull.issue
    end

    # Always render the React app for the changes action with changes-specific logic
    render_pull_requests_react(pull: @pull, range: range, mode: mode, use_changes_range: true)
  end

  def open_with_menu # rubocop:todo GitHub/UseRestfulActions
    redirect_or_error = ensure_valid_pull_request
    return redirect_or_error if performed?

    render Codespaces::CodeMenuDropdownComponent.new(
      visibility: codespaces_menu_visibility,
      repository: current_repository,
      pull_request: @pull,
      ref: params[:ref]
    ), layout: component_fragment_layout
  end

  def code_menu_contents # rubocop:todo GitHub/UseRestfulActions
    return render_404 unless T.must(request).xhr?

    redirect_or_error = ensure_valid_pull_request
    return redirect_or_error if performed?

    render Codespaces::CodeMenuContentsComponent.new(
      visibility: codespaces_menu_visibility,
      pull_request: @pull,
      repository: current_repository,
    ), layout: component_fragment_layout
  end

  def changes_since_last_review # rubocop:todo GitHub/UseRestfulActions
    redirect_or_error = ensure_valid_pull_request
    return redirect_or_error if performed?

    unless logged_in?
      return redirect_to pull_request_diff_range_path(@pull)
    end

    unless most_recent_review = @pull.latest_non_pending_review_for(current_user)
      return redirect_to pull_request_diff_range_path(@pull)
    end

    unless most_recent_review.pull_request_has_changed? && most_recent_review.applies_to_current_diff?
      return redirect_to pull_request_diff_range_path(@pull)
    end

    redirect_to pull_request_diff_range_path(@pull, range: [most_recent_review.head_sha, "HEAD"])
  end

  def show_partial_comparison # rubocop:todo GitHub/UseRestfulActions
    raise "Unexpected partial in params: #{params[:partial]}" unless params[:partial] == "pull_requests/stale_comparison"

    unless pull = PullRequest.with_number_and_repo(params[:id].to_i, current_repository)
      return head :not_found
    end

    unless pull_comparison = PullRequest::Comparison.find(pull: pull, start_commit_oid: params[:start_commit_oid], end_commit_oid: params[:end_commit_oid], base_commit_oid: params[:base_commit_oid])
      return head :not_found
    end

    GitHub.dogstats.time("view", tags: ["subject:pull_request", "action:show_partial_render"]) do
      respond_to do |format|
        format.html do
          render partial: "pull_requests/stale_comparison", layout: partial_fragment_layout, locals: { pull: pull, pull_comparison: pull_comparison }
        end
      end
    end
  end

  def show_toc # rubocop:todo GitHub/UseRestfulActions
    pull = PullRequest.with_number_and_repo(params[:id], current_repository)
    return head :not_found unless pull

    return head :not_found unless valid_sha_param?(:sha1) &&
                                  valid_sha_param?(:sha2) && params[:sha2].present? &&
                                  valid_sha_param?(:base_sha)

    diff_options = {
      base_sha: params[:base_sha],
      base_repository: pull.base_repository,
      head_repository: pull.head_repository,
    }
    diff = GitHub::Diff.new(pull.compare_repository, params[:sha1], params[:sha2], diff_options)

    respond_to do |format|
      format.html do
        render partial: "pull_requests/diffbar/toc_menu_items",
          layout: partial_fragment_layout,
          locals: {
            summary_delta_views: diff.summary.deltas.map { |d| ::Diff::SummaryDeltaView.new(d) }
          }
      end
    end
  end

  def conversations_menu # rubocop:todo GitHub/UseRestfulActions
    pull = PullRequest.with_number_and_repo(params[:id], current_repository)
    return head :not_found unless pull

    threads = PullRequestReviewThread.where(pull_request_id: pull.id)
      .joins(:pull_request_review)
      .where.not(pull_request_review: { state: PullRequestReview.state_value(:pending) })
      .order(created_at: :desc)
      .includes(:review_comments)

    threads = threads.filter(&:conversation?)

    unresolved_threads, resolved_threads = threads.partition { |thread| thread.resolver_id.nil? }

    if params[:instrument] == "1"
      GlobalInstrumenter.instrument("pull_request.user_action",
        {
          user_id: current_user&.id,
          pull_request_id: pull.id,
          category: "conversations_menu",
          action: "opened",
          data: {
            unresolved_threads_count: unresolved_threads.length,
            resolved_threads_count: resolved_threads.length,
            unresolved_threads_ids: unresolved_threads.map { |thread| thread.id },
            resolved_threads_ids: resolved_threads.map { |thread| thread.id },
            outdated_threads: unresolved_threads.count { |t| t.outdated? } + resolved_threads.count { |t| t.outdated? },
          }
        }
      )
    end

    respond_to do |format|
      format.html do
        render partial: "pull_requests/diffbar/conversations_menu",
          layout: partial_fragment_layout,
          locals: {
            unresolved_threads: unresolved_threads,
            resolved_threads: resolved_threads,
            pull_request_id: pull.id,
          }
      end
    end
  end

  def cleanup # rubocop:todo GitHub/UseRestfulActions
    # The branch was deleted by someone else before this user
    # clicked the button. Send us to the bottom.
    if !@pull.head_ref_exist?
      raise Git::Ref::NotFound
    end

    result = @pull.cleanup_head_ref(current_user,
                              reflog_data: request_reflog_data("pull request branch delete button"))

    GitHub.dogstats.increment("pull_request", tags: ["action:cleanup", "#{result ? "result:success" : "error:invalid"}"])

    if T.must(request).xhr?
      status = result ? :ok : :unprocessable_entity
      render_head_ref_update(status: status)
    else
      if result
        flash[:notice] = "Branch deleted successfully."
      else
        flash[:error] = "Oops, something went wrong."
      end

      redirect_to pull_request_path(@pull)
    end

  # We can get here both from above where the branch has already
  # been deleted before the button is clicked, or a race condition
  # where the application code thinks the branch exists but by
  # the time we execute the git command, someone else has already deleted it.
  rescue Git::Ref::NotFound
    GitHub.dogstats.increment("pull_request", tags: ["action:cleanup", "error:already_deleted"])
    render_head_ref_update(status: :unprocessable_entity, unretryable: true)
  end

  def undo_cleanup # rubocop:todo GitHub/UseRestfulActions
    stats_key = @pull.cross_repo? ? "cross_repo" : "same_repo"

    status = :ok
    if @pull.restore_head_ref(current_user,
                              request_reflog_data("pull request branch undo button"))
      GitHub.dogstats.increment("pull_request", tags: ["action:undo_cleanup", "result:success", "repo:#{stats_key}"])
    else
      status = :unprocessable_entity
      GitHub.dogstats.increment("pull_request", tags: ["action:undo_cleanup", "error:invalid", "repo:#{stats_key}"])
    end

    render_head_ref_update(status: status, unretryable: true)
  end

  def cleanup_codespaces # rubocop:todo GitHub/UseRestfulActions
    codespaces = @pull.codespaces.can_be_deprovisioned_by_user(current_user)

    result = codespaces.all? do |codespace|
      codespace.deprovision!(reason: Codespace.deletion_reasons[:user_requested])
    end

    GitHub.dogstats.increment("codespaces.merge_merge_cleanup ", tags: ["#{result ? "result:success" : "error:invalid"}"])

    if T.must(request).xhr?
      status = result ? :ok : :unprocessable_entity
      render_head_ref_update(status: status)
    else
      if result
        flash[:notice] = "#{'Codespace'.pluralize(codespaces.size)} deleted successfully."
      else
        flash[:error] = "Some codespaces could not be deleted"
      end

      redirect_to pull_request_path(@pull)
    end
  end

  def merge # rubocop:todo GitHub/UseRestfulActions
    @pull = current_repository.issues.find_by_number(params[:id].to_i).try(:pull_request) # domain-isolation-query-violation:ignore:packages/issues (SELECT)
    return render_404 unless @pull

    allowable_merge_methods = @pull.async_allowable_merge_methods(actor: current_user).sync

    if params[:squash_commits] == "1"
      merge_method = "squash"
    elsif params[:do].present?
      merge_method = params[:do]
    else
      if allowable_merge_methods.merge_commit.allowed?
        merge_method = "merge"
      else
        merge_method = "squash"
      end
    end

    merge_method_setting = case merge_method
    when "merge"
      allowable_merge_methods.merge_commit
    when "squash"
      allowable_merge_methods.squash_merge
    when "rebase"
      allowable_merge_methods.rebase_merge
    else
      PullRequest::MergeMethodSettings::Value::Disallowed
    end

    if merge_method_setting.error?
      result, message = nil, "Failed to load repository settings. Please wait a few minutes and then try again."
    elsif merge_method_setting.disallowed?
      result, message = nil, "The selected merge method (#{merge_method}) is not allowed."
    elsif invalid_author_email?(params[:author_email])
      result, message = nil, "Invalid email for web commit."
    elsif @pull.git_merges_cleanly? && @pull.base_repository.pushable_by?(current_user)
      GitHub.dogstats.increment("pull_request", tags: ["action:merge"])

      merge_action = params[:admin_override] ? :admin_override_merge : :direct_merge

      begin
        case merge_result = PullRequests::Merge.call(
          pull_request: @pull,
          user: T.must(current_user),
          commit_title: params[:commit_title],
          commit_body: params[:commit_message],
          commit_author_email: params[:author_email],
          reflog_data: request_reflog_data("pull request merge button"),
          expected_head_sha: params[:head_sha],
          method: merge_method.to_sym,
          source: merge_action
        )
        when PullRequests::Merge::Success
          result, message = true, nil
        when PullRequests::Merge::Failure
          result, message = nil, merge_result.error_message
        else
          T.absurd(merge_result)
        end
      rescue Git::Ref::HookFailed => e
        @hook_out = e.message.force_encoding("UTF-8").scrub!
        result, message = nil, "Merging was blocked by pre-receive hooks."
      end

      begin
        if merge_method == "rebase"
          @pull.base_repository.set_sticky_merge_method(current_user, "rebase")
        elsif merge_method == "squash"
          @pull.base_repository.set_sticky_merge_method(current_user, "squash")
        elsif merge_method == "merge"
          @pull.base_repository.set_sticky_merge_method(current_user, "merge_commit")
        end
      rescue => e
        Failbot.report(e)
      end
    else
      result, message = nil, "We couldn’t merge this pull request. Reload the page before trying again."
    end

    if T.must(request).xhr?
      if result
        GitHub.dogstats.histogram("pull_request.merged.requested_reviewers.count", @pull.review_requests.pending.size)
        query_params = {
          timeline_per_page: params[:timeline_per_page],
          since: params[:since],
        }.compact

        redirect_to pull_request_post_merge_path(
          current_repository.owner_display_login,
          current_repository.name,
          @pull.number,
          format: :json,
          **query_params
        )
      else
        GitHub.dogstats.increment("pull_request", tags: ["action:merge", "error:invalid"])
        respond_to do |format|
          format.json do
            render_update_content_json({
              merging: render_to_string(
                partial: "pull_requests/merging",
                object: @pull,
                formats: :html,
                locals: {
                  merging_error: {
                    form_target: "js-merge-branch-form",
                    unretryable: !@pull.currently_mergeable?,
                    title: "Merge attempt failed",
                    message:,
                    hook_output: @hook_out,
                  },
                },
              ),
            }, status: :unprocessable_entity)
          end
        end
      end
    else
      if result
        GitHub.dogstats.histogram("pull_request.merged.requested_reviewers.count", @pull.review_requests.pending.size)
        redirect_to pull_request_path(@pull) + "#merged-event"
      else
        flash[:error] = message
        GitHub.dogstats.increment("pull_request", tags: ["action:merge", "error:invalid"])
        redirect_to pull_request_path(@pull)
      end
    end
  end

  # A successful merge XHR will redirect here to render updates.
  # We do not render in the `#merge` action to reduce the likelihood of
  # timeouts, and to avoid sending SELECT queries to cluster primaries.
  def post_merge # rubocop:todo GitHub/UseRestfulActions
    @pull = current_repository.issues.find_by_number(params[:id].to_i).try(:pull_request) # domain-isolation-query-violation:ignore:packages/issues (SELECT)
    return render_404 unless @pull

    pull_node = PullRequest::ShowLoader.issue_node(
      @pull,
      current_repository,
      current_user,
      cap_filter:,
      pagination_params: {
        per_page: params[:timeline_per_page],
        timeline_since: helpers.discussion_last_modified_at&.iso8601,
      },
    )

    respond_to do |format|
      # The `format.json` block must stay at the top here if any format
      # block is added in future, so that when the `Accept` header is `*/*`
      # we will continue to send JSON by default.
      format.json do
        render_update_content_json({
          timeline: render_to_string(
            partial: "pull_requests/timeline",
            object: @pull,
            formats: :html,
            locals: {
              pull_node: pull_node,
            },
          ),
          sidebar: render_to_string(
            partial: "pull_requests/sidebar",
            object: @pull,
            formats: :html,
            locals: {
              pull_node: pull_node,
              pull: @pull,
            },
          ),
          merging: render_to_string(
            partial: "pull_requests/merging",
            object: @pull,
            formats: :html,
          ),
          form_actions: render_to_string(
            partial: "pull_requests/form_actions",
            object: @pull,
            formats: :html,
            locals: {
              pull: @pull,
              issue_node: pull_node,
            },
          ),
          pull_request_tab_count: render_to_string(
            partial: "navigation/repository/tab_counter",
            formats: :html,
            locals: {
              count: current_repository.open_pull_request_count_for(current_user), # domain-isolation-query-violation:ignore:packages/issues (SELECT)
              label: "Pull requests"
            }
          ),
        })
      end
    end
  end

  def change_base # rubocop:todo GitHub/UseRestfulActions
    return render_404 unless params[:new_base_binary]

    @pull = find_pull_request
    return render_404 unless @pull && @pull.issue.can_modify?(current_user)

    new_base = Base64.decode64(params[:new_base_binary])
    unless new_base.present?
      return redirect_to pull_request_path(@pull), flash: { error: "Please select a base branch." }
    end

    if T.must(request).xhr?
      change_branch_async
    else
      begin
        @pull.change_base_branch(current_user, new_base)
        flash[:notice] = "Updated base branch to #{new_base}."
      rescue PullRequest::BaseNotChangeableError => e
        flash[:error] = e.ui_message
      end
      redirect_to pull_request_path(@pull)
    end
  end

  def update_branch # rubocop:todo GitHub/UseRestfulActions
    @pull = find_pull_request
    return render_404 unless @pull

    update_method = params[:update_method] == "rebase" ? "rebase" : "merge"
    result = PullRequests::UpdateBranch.execute(pull_request: @pull, user: T.must(current_user), update_method:, expected_head_oid: params[:expected_head_oid])

    case result
    when PullRequests::UpdateBranch::Success
      render json: { orchestration: { url: pull_request_orchestration_status_url(orchestration_id: result.orchestration.id) } }
    when PullRequests::UpdateBranch::Error
      render json: { error_message: result.error_message }, status: :unprocessable_entity
    else
      T.absurd(result)
    end
  end

  def revert # rubocop:todo GitHub/UseRestfulActions
    @pull = find_pull_request
    return render_404 unless @pull && @pull.revertable_by?(current_user)

    stats_key = @pull.cross_repo? ? "cross_repo" : "same_repo"

    begin
      revert_branch, error = @pull.revert(current_user, request_reflog_data("pull request revert button"), timeout: (request_time_left / 3))
      if revert_branch
        GitHub.dogstats.increment("pull_request", tags: ["action:revert", "repo:#{stats_key}"])

        base_label, head_label =
          if revert_branch.repository == @pull.base_repository
            [@pull.base_ref_name, revert_branch.name]
          else
            ["#{@pull.base_label(username_qualified: true)}", "#{revert_branch.repository.owner.display_login}:#{revert_branch.name}"]
          end

        flash[:pull_request] = {
          title: "Revert \"#{@pull.title}\"",
          body: "Reverts #{@pull.base_repository.name_with_display_owner}##{@pull.number}",
        }
        redirect_to(compare_path(@pull.base_repository, "#{base_label}...#{head_label}", expand: true))
      else
        if error == :merge_conflict
          GitHub.dogstats.increment("pull_request", tags: ["action:revert", "error:merge_conflict"])
        else
          GitHub.dogstats.increment("pull_request", tags: ["action:revert", "error:invalid"])
        end

        flash[:error] = "Sorry, this pull request couldn’t be reverted automatically. It may have \
                         already been reverted, or the content may have changed since it was merged."
        redirect_to pull_request_path(@pull)
      end
    rescue Git::Ref::HookFailed => e
      flash[:hook_out] = e.message
      flash[:hook_message] = "Pull request could not be reverted."
      redirect_to pull_request_path(@pull)
    rescue Git::Ref::RepositoryRuleViolationError => e
      logger_params = {
        "gh.pull_request.id": @pull.id,
        "gh.pull_request.action": "revert",
        "gh.pull_request.error_details": e.detailed_message
      }

      GitHub.logger.error("failed to revert pull request", logger_params)
      Failbot.report(e, logger_params)

      flash[:revert_error_heading] = e.message
      flash[:revert_error_details] = e.failed_runs.map(&:message).join("\n\n")
      redirect_to pull_request_path(@pull)
    end
  end

  def merge_button # rubocop:todo GitHub/UseRestfulActions
    pull = PullRequest.with_number_and_repo(params[:id].to_i, current_repository, include: [:auto_merge_request])

    return render_404 if pull.nil?
    merge_state = pull.cached_merge_state(viewer: current_user)

    # explicitly force firing off the merge commit job if needed
    pull.enqueue_mergeable_update(priority: :high)

    if pull.auto_merge_request
      GitHub.instrument(
        "pull_requests_controller.merge_button",
        pull_request_id: pull.id,
        actor_id: T.must(current_user).id,
        repo_id: current_repository.id,
        merge_state: merge_state.status,
        auto_merge_error: pull.auto_merge_request.merge_error
      )
    end

    respond_to do |format|
      format.html do
        if merge_state.unknown?
          head :accepted
        else
          render partial: "pull_requests/merge_button", locals: { pull: pull }
        end
      end

      format.json do
        render json: { mergeable_state: merge_state.status }.to_json
      end
    end
  end

  def diff # rubocop:todo GitHub/UseRestfulActions
    # This might be a request for a redirect to the PR for a branch name ending in .diff,
    # or might be a request for a numbered PR in .diff format.
    diff_ref = "#{params[:id]}.diff"
    if current_repository.heads.include?(diff_ref)
      return redirect_or_404(diff_ref)
    end

    redirect_or_error = ensure_valid_pull_request
    if performed?
      redirect_or_error
    else
      redirect_to build_pull_request_diff_url
    end
  end

  def patch # rubocop:todo GitHub/UseRestfulActions
    # This might be a request for a redirect to the PR for a branch name ending in .patch,
    # or might be a request for a numbered PR in .patch format.
    patch_ref = "#{params[:id]}.patch"
    if current_repository.heads.include?(patch_ref)
      return redirect_or_404(patch_ref)
    end

    redirect_or_error = ensure_valid_pull_request
    if performed?
      redirect_or_error
    else
      redirect_to build_pull_request_patch_url
    end
  end

  def comment # rubocop:todo GitHub/UseRestfulActions
    @pull = current_repository.issues.find_by_number(params[:id].to_i).try(:pull_request) # domain-isolation-query-violation:ignore:packages/issues (SELECT)
    return if reject_bully?(@pull)
    return render_404 unless @pull
    issue = @pull.issue

    valid = true
    comment_body = params[:comment][:body]

    if !comment_body.nil? && !can_skip_creating_comment?
      comment = issue.create_comment(current_user, comment_body) # domain-isolation-query-violation:ignore:packages/issues (SELECT)
      valid &&= comment.persisted?

    elsif params[:comment_and_close] == "1"
      comment = issue.comment_and_close(current_user, comment_body) # domain-isolation-query-violation:ignore:packages/issues (SELECT, UPDATE)
      valid &= comment if comment_body.present?

      GitHub.dogstats.increment("pull_request.closed", tags: ["with_comment:#{comment_body.present?}"])
      GitHub.dogstats.histogram("pull_request.closed.requested_reviewers.count", @pull.review_requests.pending.size)

    elsif params[:comment_and_open] == "1"
      comment = issue.comment_and_open(current_user, comment_body) # domain-isolation-query-violation:ignore:packages/issues (SELECT, UPDATE)
      valid &= comment if comment_body.present?
    end

    mark_pull_notification_as_read issue
    if valid && comment_body.present?
      GitHub.instrument "comment.create", user: current_user
      instrument_saved_reply_use(params[:saved_reply_id], "pull_request_comment")
    end

    respond_to do |format|
      # The `format.json` block must stay at the top here if any format
      # block is added in future, so that when the `Accept` header is `*/*`
      # we will continue to send JSON by default.
      format.json do
        if !valid
          errors = comment.errors.map(&:message)
          return render json: { errors: errors }, status: :unprocessable_entity
        end

        if params[:context] == "project_sidebar"
          render_update_content_json({
            state_button_wrapper: render_to_string(
              partial: "pull_requests/state_button_wrapper",
              object: @pull,
              formats: :html,
              locals: {
                pull: @pull,
                addl_btn_classes: ["width-full mt-2"],
              },
            )
          })
        else
          # we reload the pull request here to get the updated list of commits since it can change if we reopen a closed PR
          pull_node = PullRequest::ShowLoader.issue_node(
            @pull.reload,
            current_repository,
            current_user,
            cap_filter: cap_filter,
            pagination_params: { per_page: params[:timeline_per_page], timeline_since: helpers.discussion_last_modified_at&.iso8601 }
          )
          partials = {
            timeline: render_to_string(
              partial: "pull_requests/timeline",
              object: @pull,
              formats: :html,
              locals: { pull_node: pull_node }
            )
          }
          if params[:comment_and_close].present? || params[:comment_and_open].present?
            partials.merge!({
              merging: render_to_string(
                partial: "pull_requests/merging",
                object: @pull,
                formats: :html,
              ),
              form_actions: render_to_string(
                partial: "pull_requests/form_actions",
                object: @pull,
                formats: :html,
                locals: {
                  pull: @pull,
                  issue_node: pull_node,
                },
              ),
              title: render_to_string(
                partial: "pull_requests/title",
                object: @pull,
                formats: :html,
                locals: {
                  sticky: params[:sticky] == "true",
                },
              ),
              pull_request_tab_count: render_to_string(
                partial: "navigation/repository/tab_counter",
                formats: :html,
                locals: {
                  count: current_repository.open_pull_request_count_for(current_user), # domain-isolation-query-violation:ignore:packages/issues (SELECT)
                  label: "Pull requests"
                }
              )
            })
          end
          render_update_content_json(partials)
        end
      end
      format.html do
        if valid
          anchor = comment ? "#issuecomment-#{comment.id}" : ""
          redirect_to pull_request_path(@pull) + anchor
        else
          flash[:error] = comment.errors.full_messages.to_sentence
          redirect_to :back
        end
      end
    end
  rescue ActiveRecord::RecordInvalid => e
    respond_to do |format|
      format.html do
        flash[:error] = e.record.errors.full_messages.to_sentence
        return redirect_to :back
      end
      format.json do
        errors = e.record.errors.map { |error| error.message }
        return render json: { errors: errors.to_sentence }, status: :unprocessable_entity
      end
    end
  end

  def dismiss_protip # rubocop:todo GitHub/UseRestfulActions
    T.must(current_user).dismiss_notice("continuous_integration_tip")

    head :ok
  end

  def set_collab # rubocop:todo GitHub/UseRestfulActions
    pull = current_repository.issues.find_by_number(params[:id].to_i).try(:pull_request)

    return render_404 if !pull || !pull.head_repository.repository.pushable_by?(current_user)

    if !!params[:collab_privs]
      pull.fork_collab_allowed!
    else
      pull.fork_collab_denied!
    end

    redirect_to pull_request_path(pull)
  end

  def resolve_conflicts # rubocop:todo GitHub/UseRestfulActions
    redirect_or_error = ensure_valid_pull_request
    return redirect_or_error if performed?

    unless logged_in? && @pull.head_repository && @pull.head_repository.pushable_by?(current_user, ref: @pull.head_ref_name)
      return render_404
    end

    can_push_merge_to_head = !@pull.head_branch_rule_evaluator&.required_linear_history_enabled?

    unless @pull.conflict_resolvable? && conflict_editor_enabled?(@pull) && can_push_merge_to_head
      return redirect_to pull_request_path(@pull)
    end

    @hide_footer = true
    render "pull_requests/resolve_conflicts", locals: { pull: @pull }
  end

  def ready_for_review # rubocop:todo GitHub/UseRestfulActions
    return render_404 unless ensure_valid_pull_request

    return render_404 unless @pull.can_mark_ready_for_review?(current_user)

    begin
      @pull.ready_for_review!(user: current_user)
      flash[:notice] = "Marked pull request as ready for review."
    # ActiveRecord::RecordInvalid is the most expected exception type from `#ready_for_review!`
    # In case an exception with diff. type took place, user will see the Unicorn 500 error page
    # In that case, we will add the other exception type
    rescue ActiveRecord::RecordInvalid => e
      Failbot.report(e, "gh.pull_request.id": @pull.id)
      flash[:error] = "Something went wrong!"
    end

    redirect_to :back
  end

  def convert_to_draft # rubocop:todo GitHub/UseRestfulActions
    ensure_valid_pull_request
    return if performed?

    return render_404 unless @pull.can_convert_to_draft?(current_user)

    @pull.convert_to_draft(user: current_user)

    if T.must(request).xhr?
      head :ok
    else
      flash[:notice] = "Pull request review paused."
      redirect_back fallback_location: pull_request_path(@pull), allow_other_host: false
    end
  end

  class BadSuggestionError < StandardError; end

  def apply_suggestions # rubocop:todo GitHub/UseRestfulActions
    @pull = find_pull_request
    return render_404 unless @pull

    json = GitHub::JSON.parse(params[:changes])
    changes = Array(json).map do |change|
      raise BadSuggestionError unless change.respond_to?(:fetch)
      {
        commentId: change.fetch("commentId", ""),
        path: change.fetch("path", ""),
        suggestion: change.fetch("suggestion", []),
      }
    end

    inputs = {
      pull_request: @pull,
      changes: changes,
      message: params[:message].to_s,
      current_oid: params[:current_oid],
      sign: true
    }

    # Doing one query to find all review comments that will be used later on by `PullRequestReviewComment::ApplySuggestedChange#call`
    review_comments = begin
      PullRequestReviewComment.find(changes.map { |c| c[:commentId] })
    rescue ActiveRecord::RecordNotFound => e
      return render json: { error: "One or more of the suggestion comments has been deleted." }, status: :not_found
    end

    review_comments_hash = Hash[review_comments.map { |c| [c.id, c] }]

    changes = changes.map do |change|
      {
        path: change[:path],
        suggestion: change[:suggestion],
        comment: review_comments_hash[change[:commentId].to_i]
      }
    end

    inputs.merge!(
      changes: changes,
      viewer: current_user,
      remote_ip: T.must(request).remote_ip,
      user_agent: T.must(request).user_agent
    )

    begin
      PullRequestReviewComment::ApplySuggestedChange.call(inputs)
    rescue PullRequestReviewComment::ApplySuggestedChange::NotFoundError => e
      return render json: { error: e.message }, status: :not_found
    rescue PullRequestReviewComment::ApplySuggestedChange::ForbiddenError => e
      return render json: { error: e.message }, status: :forbidden
    rescue PullRequestReviewComment::ApplySuggestedChange::UnprocessableError => e
      return render json: { error: e.message }, status: :unprocessable_entity
    end

    flash[:notice] = "#{"Suggestion".pluralize(inputs[:changes].count)} successfully applied."
    head :ok
  rescue GitHub::JSON::ParseError, BadSuggestionError
    render json: { error: "Sorry, the changes couldn't be applied." }, status: :unprocessable_entity
  end

  def run_action_required_workflows # rubocop:todo GitHub/UseRestfulActions
    @pull = find_pull_request
    return render_404 unless @pull
    return render_404 unless current_repository.writable_by?(current_user)

    workflow_run_ids = []
    rerun_failed = T.let(false, T::Boolean)
    @pull.action_required_check_suites(head_sha: @pull.head_sha).each do |check_suite|
      begin
        check_suite.rerequest(actor: current_user)
        workflow_run_ids << check_suite.workflow_run.id
      rescue CheckSuite::ActionsDependency::ExpiredWorkflowRunError, CheckSuite::AlreadyRerunningError, CheckSuite::DisabledWorkflowError, CheckSuite::NotRerequestableError => e
        rerun_failed = true
        flash[:error] = "Unable to re-run one or more workflows. Check if the workflows are already running, are more than 30 days old, or are disabled."
        GitHub.dogstats.increment("workflow.action_required_rerquest_failed", tags: ["error:#{e.class.name&.demodulize}"])
      end
    end

    GlobalInstrumenter.instrument("workflow.action_required_approved", {
      pull_request_id: @pull.id,
      actor_id: T.must(current_user).id,
      repo_id: current_repository.id,
      workflow_run_ids: workflow_run_ids.sort!,
    })

    if request.xhr? || use_verified_fetch?
      if rerun_failed
        render json: { error: "Unable to re-run one or more workflows. Check if the workflows are already running, are more than 30 days old, or are disabled." }, status: :unprocessable_entity
      else
        head :ok
      end
    else
      redirect_to pull_request_path(@pull)
    end
  end

  # deferred_commits_data takes two optional parameters:
  #    results_to_fetch - integer indicating how big of a window to grab
  #    start_entry - integer indicating where to begin within the pull commits list for grabbing async data
  def deferred_commits_data # rubocop:todo GitHub/UseRestfulActions
    @pull = find_pull_request
    return render_404 unless @pull
    return render_404 if @pull.hide_from_user?(current_user)

    commits = @pull.changed_commits
    commit_count = commits.length
    start_index = params[:start_entry].to_i
    results_to_fetch = params[:results_to_fetch].nil? ? COMMITS_TO_FETCH_DATA_FOR_AT_A_TIME : params[:results_to_fetch].to_i
    commits = commits.slice(start_index, results_to_fetch)
    next_starting_index = start_index + results_to_fetch > commit_count ? commit_count : start_index + results_to_fetch
    load_more = next_starting_index != commit_count

    respond_to do |format|
      format.json do
        render json: { deferredCommits: build_deferred_commit_payload(commits, current_repository, current_user),
          nextIndex: next_starting_index,
          loadMore: load_more,
          #loading is set to false because that is how we tell the front end that we have gotten the first set
          #of results back
          loading: false }
      end
    end
  end

  protected

  def use_actions_ux?
    false
  end
  helper_method :use_actions_ux?

  def valid_tab?
    params[:tab].blank? || %w{discussion commits files tasks checks findings}.include?(params[:tab])
  end

  def reject_bully?(pull = nil)
    return false if current_user_can_push?
    if blocked_by_owner? || (pull && blocked_by_author?(pull.user))
      flash[:error] = "You can't perform that action at this time."
      redirect_to current_repository.permalink
      true
    end
  end

  private

  def global_nav_selected_link
    :repo_pulls
  end

  # Private: Checks if the viewer can lock the current issue.
  def require_can_lock
    redirect_to :back unless current_issue.lockable_by?(current_user)
  end

  # Private: Checks if the viewer can unlock the current issue.
  def require_can_unlock
    redirect_to :back unless current_issue.unlockable_by?(current_user)
  end

  # Private: Checks if the viewer can archive the current pull request.
  def require_can_archive
    pull = current_issue&.pull_request
    redirect_to :back unless pull&.archivable_by?(current_user)
  end

  # Private: Checks if the viewer can unarchive the current pull request.
  def require_can_unarchive
    pull = current_issue&.pull_request
    redirect_to :back unless pull&.unarchivable_by?(current_user)
  end

  def set_milestone_permission_required
    render_404 unless current_issue.can_set_milestone?(current_user)
  end

  def tracking_issues_enabled?
    !GitHub.enterprise?
  end

  def tracking_issues
    return [] unless tracking_issues_enabled?
    return [] unless @issue

    @issue.normalized_tracking_issues( # domain-isolation-query-violation:ignore:packages/issues (SELECT)
      viewer: current_user,
      cap_filter: cap_filter,
    )
  end

  def indifferent_params
    params_value = params
    if params_value.is_a?(ActionController::Parameters)
      params_value.permit!.to_h.with_indifferent_access
    else
      params_value.to_h.with_indifferent_access
    end
  end

  def create_milestone(title)
    ActiveRecord::Base.connected_to(role: :reading) do
      return unless current_user_can_push?
    end
    return unless title

    milestone = ActiveRecord::Base.connected_to(role: :reading) do
      m = current_repository.milestones.build(title: title)
      m.created_by = current_user
      m
    end
    milestone if milestone.save
  end

  def patch_action_request_is_rate_limited?
    !logged_in?
  end

  # Issue page <title>. This is "Issues - <user>/<repo>" for index pages
  # or "<issue.title> - Issues - <user>/<repo>" for individual issue pages.
  def issue_page_title(issue = nil)
    [("#{issue.title} · Issue ##{issue.number}" if issue),
      ("Issues" if !issue),
      current_repository.name_with_display_owner,
    ].compact.join(" · ")
  end

  def issue_update_payload(item, errors = [])
    payload = {
      issue_title: item.title,
      source: item.body,
      body: item.body_html(context: { viewer: current_user, cap_filter: cap_filter, unfurl_references: true }),
      newBodyVersion: item.body_version,
      editUrl: show_comment_edit_history_path(item.global_relay_id),
      errors: errors
    }

    if item.pull_request?
      payload[:page_title] = pull_request_page_title(item)
      payload[:default_squash_commit_title] = item.pull_request.default_squash_commit_title
      payload[:default_merge_commit_title] = item.pull_request.default_merge_commit_title
      payload[:default_squash_commit_message] = item.pull_request.default_squash_commit_message
      payload[:default_merge_commit_message] = item.pull_request.default_merge_commit_message
    else
      payload[:page_title] = issue_page_title(item)
    end

    if item.respond_to?(:labels)
      payload[:labels] = render_to_string(
        partial: "issues/labels",
        object: item.labels,
        formats: [:html],
      )
    end

    payload
  end

  def populate_assignees
    if current_repository
      users = current_repository.visible_available_assignees_for(current_user).limit(GitHub.assignees_list_limit).to_a || []
      users.sort! { |a, b| a.display_login.downcase <=> b.display_login.downcase }

      if logged_in?
        users.delete(current_user)
        users.unshift(current_user)
      end

      users
    else
      [current_user]
    end
  end
  helper_method :populate_assignees

  def pulls_only? # rubocop:todo GitHub/ControllersShouldUseMemoizeForMemoization
    return @_pulls_only if defined?(@_pulls_only)
    @_pulls_only = ActiveRecord::Type::Boolean.new.deserialize(params[:pulls_only])
  end

  def populate_authors
    if current_repository
      distinct_authors_scope = current_repository.issues.order(created_at: :desc)

      distinct_authors_scope = distinct_authors_scope.with_pull_requests if pulls_only?
      distinct_author_ids = distinct_authors_scope.distinct(:user_id).limit(GitHub.authors_list_limit).pluck(:user_id) # domain-isolation-query-violation:ignore:packages/issues (SELECT)
      users = User.where(id: distinct_author_ids).includes(:profile).to_a

      GitHub.dogstats.increment("issues.authors_list_limit.exceeded") if distinct_author_ids.size >= GitHub.authors_list_limit
      GitHub.logger.info("Issues authors list limit exceeded", {
        "gh.repository.id": current_repository.id,
        "gh.repository.nwo": current_repository.name_with_display_owner,
      })

      users.sort! { |a, b| a.display_login.downcase <=> b.display_login.downcase }

      if cu = current_user
        users.delete(cu)
        users.unshift(cu)
      end

      users
    else
      [current_user]
    end
  end
  helper_method :populate_authors

  def patch_action_rate_limit_key
    key_base = "#{self.class.to_s.underscore}:#{action_name}"
    actor_identifier = request.env.fetch("HTTP_X_SSL_JA3_HASH", nil)
    actor_identifier = request.remote_ip if actor_identifier.blank?
    "#{key_base}:#{actor_identifier}"
  end

  def change_branch_async
    new_base = Base64.decode64(params[:new_base_binary])

    result = PullRequests::ChangeBase.execute(pull_request: @pull, user: T.must(current_user), new_base:)

    case result
    when PullRequests::ChangeBase::Success
      render json: { orchestration: { url: pull_request_orchestration_status_url(orchestration_id: result.orchestration.id) } }
    when PullRequests::ChangeBase::Error
      render json: { error_message: result.error_message }, status: :unprocessable_entity
    else
      T.absurd(result)
    end
  end

  def set_page_responsive
    @page_responsive = true
  end

  def record_stats
    if action_name == "files"
      stats.add_tags "defer_syntax_highlighted_diffs:true"
    end

    stats.instrument_controller_action do
      yield
      response.successful?
    end
  end

  def find_pull_request
    PullRequest.with_number_and_repo(params[:id].to_i, current_repository, include: [{ issue: :comments }])
  end

  # Private: For a given ref name, redirect to the appropriate pull request
  # path if one exists, or 404 otherwise.
  #
  # Returns the redirect or render_404 result.
  def redirect_or_404(ref)
    # redirect to number version if ref is a branch name,
    # redirect to new if ref is a branch with no pull request
    # 404 otherwise
    if pull = current_repository.pull_requests.for_branch(ref).last
      redirect_to pull_request_path(pull)
    elsif ref =~ /[:.]/ || current_repository.heads.include?(ref)
      redirect_to new_pull_request_path(range: ref)
    else
      render_404
    end
  rescue ActionController::UrlGenerationError
    render_404
  end

  # Private: Validate the requested pull request ID. If necessary redirect to
  # a more appropriate URL or return a 404 if the PR isn't/shouldn't be
  # available.
  def ensure_valid_pull_request
    GitHub.dogstats.time("pull_request.ensure_valid_pull_request", tags: dogstats_request_tags) do
      if params[:id] =~ /\D/
        return redirect_or_404(params[:id])
      end

      @pull = find_pull_request

      return redirect_to(issue_path(id: params[:id])) unless @pull
      return redirect_to(pull_request_path @pull) unless valid_tab?

      return render_404 if @pull.hide_from_user?(current_user)
      return render_404 if @pull.archived_and_hidden_from?(current_user)

      @prose_url_hints = { tab: "files" }

      @pull.set_diff_options(
        use_summary: true,
        ignore_whitespace: ignore_whitespace?(@pull, params, current_user, logged_in?),
      )
    end
  end

  def conflict_editor_enabled?(pull)
    return true unless pull.cross_repo?

    GitHub.cross_repo_conflict_editor_enabled?
  end

  # Validates the provided parameter is a valid sha, or nil
  def valid_sha_param?(param_name)
    param = params[param_name]
    param.nil? || GitRPC::Util.valid_full_oid?(param)
  end

  def load_diff
    @pull_comparison.ignore_whitespace = ignore_whitespace?(@pull_comparison.pull, params, current_user, logged_in?)
    @pull_comparison.diff_options[:use_summary] = true
    @pull_comparison.diff_options[:top_only] = true

    GitHub.dogstats.time("diff.load.initial", tags: dogstats_request_tags) do
      @pull_comparison.diffs.apply_auto_load_single_entry_limits!
      @pull_comparison.diffs.load_diff(timeout: request_time_left / 2)
    end
  end

  # Prepare for rendering the files tab
  #
  # pull_comparison - PullRequest::Comparison specifying whether the PR's diff will be rendered.
  #
  # Returns nothing.
  def prepare_for_rendering_files(pull_comparison:)
    return unless pull_comparison

    CodeScanning::ReviewCommentComponent.preload_review_comments(pull_request: @pull)

    review_threads = pull_comparison.review_threads_for(viewer: current_user)

    review_threads = review_threads.map(&:activerecord_pull_request_review_thread)

    file_threads = pull_comparison.file_review_threads_for(viewer: current_user).map(&:activerecord_pull_request_review_thread)
    review_threads.concat(file_threads)

    GitHub::PrefillAssociations.prefill_associations(review_threads, :pull_request_review)
    review_threads.each { |thread| thread.current_comparison = pull_comparison }

    PullRequests::ReviewThreadComponent.preload_review_threads(review_threads: review_threads, viewer: current_user, pull_request: @pull)

    review_comments = review_threads.flat_map do |thread|
      page_info = thread.prelude_paginated_review_comments_for(current_user, PullRequests::ReviewThreadBodyComponent.pagination_params)
      page_info[:first_group] + (page_info[:last_group] || [])
    end
    GitHub::PrefillAssociations.prefill_associations(review_comments, :repository, available_records: [current_repository])

    PullRequests::ReviewCommentComponent.preload_review_comments(
      review_comments: review_comments,
      reviews: review_threads.map(&:pull_request_review),
      pull_request: @pull,
      viewer: current_user,
      cap_filter: cap_filter
    )
  end

  def can_skip_creating_comment?
    params[:comment_and_close].present? ||
      params[:comment_and_open].present?
  end

  # If it's empty, you can't issue a pull request.  There will be no
  # base SHA to merge against.
  def check_for_empty_repository
    if current_repository.empty?
      redirect_to current_repository
    end
  end

  def ensure_pull_head_pushable
    @pull = current_repository.issues.find_by_number(params[:id].to_i).try(:pull_request) # domain-isolation-query-violation:ignore:packages/issues (SELECT)
    return render_404 if @pull.nil?
    return writable_repository_required unless @pull.head_repository.writable?
    render_404 unless @pull.head_repository.pushable_by?(current_user)
  end

  # Reload the pull so the deletable/restorable status is current,
  # then render updates for the event list and the merge/delete buttons.
  def render_head_ref_update(status:, unretryable: false)
    @pull.reload
    merging_error = nil
    if status == :unprocessable_entity
      merging_error = { form_target: "js-cleanup-branch-form", unretryable: unretryable }
    end
    respond_to do |format|
      # The `format.json` block must stay at the top here if any format
      # block is added in future, so that when the `Accept` header is `*/*`
      # we will continue to send JSON by default.
      format.json do
        pull_node = PullRequest::ShowLoader.issue_node(@pull, current_repository, current_user, cap_filter: cap_filter, pagination_params: { per_page: params[:timeline_per_page], timeline_since: helpers.discussion_last_modified_at&.iso8601 })
        render_update_content_json({
          timeline: render_to_string(
                partial: "pull_requests/timeline",
                object: @pull,
                formats: :html,
                locals: {
                  pull_node: pull_node,
                },
              ),
              merging: render_to_string(
                partial: "pull_requests/merging",
                object: @pull,
                formats: :html,
                locals: {
                  merging_error: merging_error,
                },
              ),
              form_actions: render_to_string(
                partial: "pull_requests/form_actions",
                object: @pull,
                formats: :html,
                locals: {
                  pull: @pull,
                  issue_node: pull_node,
                },
              ),
        }, status: status)
      end
    end
  end

  # Internal: Provide a better failure message than simply taking the validation errors
  #
  # e - the ActiveRecord::RecordInvalid exception from the creation failure
  #
  # Returns a String
  def human_failure_message(e)
    pr = e.record

    # e.record can be an Issue, raised in PullRequest.create_for.
    return e.message unless pr.is_a?(PullRequest)

    if bad_branches = pr.missing_refs
      if bad_branches.length == 1
        "The #{bad_branches.first} branch doesn’t exist."
      else
        "The #{bad_branches.join(' and ')} branches don’t exist."
      end
    elsif [:base_ref, :head_ref].any? { |attr| pr.errors[attr].include?(GitHub::Validations::Unicode3Validator::ERROR_MESSAGE) }
      "Branch names cannot contain unicode characters above 0xffff."
    else
      e.message
    end
  end

  def pull_request_authorization_token
    T.must(current_user).signed_auth_token expires: 60.seconds.from_now,
                                   scope: pull_request_authorization_token_scope_key
  end

  def build_pull_request_diff_url
    route_options ||= {}

    if GitHub.prs_content_domain?
      route_options[:host] = GitHub.prs_content_host_name
    end

    if current_repository.private?
      route_options[:token] = pull_request_authorization_token
    end

    route_options[:full_index] = params[:full_index]

    pull_request_raw_diff_url(route_options)
  end

  def build_pull_request_patch_url
    route_options ||= {}

    if GitHub.prs_content_domain?
      route_options[:host] = GitHub.prs_content_host_name
    end

    if current_repository.private?
      route_options[:token] = pull_request_authorization_token
    end

    route_options[:full_index] = params[:full_index]

    pull_request_raw_patch_url(route_options)
  end

  def request_reflog_data(via)
    super(via).merge({ pr_author_login: @pull.safe_user.display_login })
  end

  def content_authorization_required
    authorize_content(:pull_request, repo: current_repository)
  end

  def invalid_author_email?(author_email)
    author_email && (!GitHub.choose_commit_email_enabled? || !current_user&.author_emails.include?(author_email))
  end

  def route_supports_advisory_workspaces?
    return false if action_name == "merge"
    return true unless action_name == "show"

    %w(discussion status commits files).include?(specified_tab)
  end

  def no_cache
    return unless T.must(request).get?
    expires_now
  end

  # Override AbstractRepositoryController#defer_commit_badges? to
  # opt-in to deferred loading of commit signature badges.
  def defer_commit_badges?
    true
  end

  # Override AbstractRepositoryController#defer_status_check_rollups? to
  # opt-in to deferred loading of status check rollups
  def defer_status_check_rollups?
    true
  end

  def mark_pull_notification_as_read(thread)
    async_mark_thread_as_read thread
  end

  memoize def default_merge_method
    Platform::Models::PullRequestMergeRequirements.new(@pull, nil, nil, nil, current_user).merge_method.sync.upcase
  end

  def use_repository_cluster_replicas(&block)
    use_replica_clusters([ApplicationRecord::Repositories], &block)
  end

  def use_user_cluster_replicas(&block)
    use_replica_clusters([ApplicationRecord::Mysql1], &block)
  end

  def use_collab_cluster_replicas(&block)
    use_replica_clusters([ApplicationRecord::Collab], &block)
  end

  def index_flow # rubocop:todo GitHub/ControllersShouldUseMemoizeForMemoization
    @index_flow ||= Issue::ControlFlow.new(
      params: params,
      pulls_only: true, # Always true in the pull requests controller
      repo:   current_repository,
      components: parsed_issues_query,
      current_user: current_user,
      current_path: T.must(request).fullpath,
    )
  end

  # Enforces archived PR visibility rules on the parsed search query
  def filter_archived_prs(query)
    return query unless current_repository && FeatureFlag.vexi.enabled?(:archive_pull_request, current_repository, default: false)

    is_repo_admin = current_repository.adminable_by?(current_user)
    Search::Queries::IssueQuery.enforce_archived_pr_visibility(query, is_admin: is_repo_admin)
  end

  def external_identity_session_required
    if !current_user&.feature_flag_enabled?(:issues_react_enforce_sso, default: false) && !current_repository.owner.feature_flag_enabled?(:issues_react_enforce_sso, default: false)
      return
    end
    unless required_external_identity_session_present?(target: current_repository.owner)
      render_external_identity_session_required(target: current_repository.owner)
    end
  end

  # A filter to check whether you have permission to modify this issue or group
  # of issues.
  #
  # Redirects away unless you have access.
  def issue_modifiers_only
    return redirect_to_login unless logged_in?
    return redirect_to "/" unless current_repository

    allowed = if current_issue
      current_issue.editable_by?(current_user)
    else
      current_user_can_push?
    end

    redirect_to "/" unless allowed
  end

  def network_privilege_check
    with_replica_repository_cluster { super }
  end

  # Private: Returns the target entity for user name display configuration.
  #
  # This method determines which entity's user name display settings should be used
  # when rendering user names in the pull request context. For pull requests, we use
  # the repository's organization configuration if available.
  #
  # Returns an Organization or nil if the repository is not owned by an organization.
  def target_for_user_name_display_configuration
    current_repository&.organization
  end

  # Handle all route redirects between files/commits and the changes action
  def handle_changes_route_redirects
    return unless current_repository

    range = params[:range]
    base_path = "/#{current_repository.name_with_display_owner}/pull/#{params[:id]}"
    changes_route_enabled = unified_changes_route_enabled?(current_user, params)

    case action_name
    when "files"
      # files → changes (when feature flags enabled)
      if changes_route_enabled
        redirect_url = if range.present?
          # Ensure range is in BASE..HEAD format
          new_range = range.include?("..") ? range : "BASE..#{range}"
          "#{base_path}/changes/#{new_range}"
        else
          "#{base_path}/changes"
        end

        override_action_tag_for_redirect("files_redirect")
        redirect_to append_changes_redirect_query_params(redirect_url)
      end

    when "commits"
      # commits → changes (when feature flags enabled and range present)
      if changes_route_enabled && range.present?
        redirect_url = "#{base_path}/changes/#{range}"
        override_action_tag_for_redirect("commits_redirect")
        redirect_to append_changes_redirect_query_params(redirect_url)
      end

    when "changes"
      # changes → files/commits (when feature flags disabled)
      unless changes_route_enabled
        if range.present?
          # Determine if this should go to commits or files based on range format
          if range.include?("..")
            # Range format: goes to files
            redirect_url = "#{base_path}/files/#{range}"
          else
            # Single OID: goes to commits
            redirect_url = "#{base_path}/commits/#{range}"
          end
        else
          # No range: goes to files
          redirect_url = "#{base_path}/files"
        end

        override_action_tag_for_redirect("changes_redirect")
        redirect_to append_changes_redirect_query_params(redirect_url)
      end
    end
  end

  # Append query params to changes route redirects
  def append_changes_redirect_query_params(base_url)
    query_params = request.query_parameters
    return base_url if query_params.empty?

    "#{base_url}?#{query_params.to_query}"
  end

  # Override the action tag for redirects related to files/changes/commits navigation
  # This is so we don't skew request times for the original action in telemetry
  def override_action_tag_for_redirect(action_tag)
    GitHub::TaggingHelper.override_action_tag(env: env, action: action_tag)
  end

  def disable_turbo_navigation
    disable_turbo
  end
end
